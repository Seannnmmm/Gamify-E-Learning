const wordList = [
    {
        word: "lan",
        hint: "A network that connects computers within a limited area."
    },
    {
        word: "wan",
        hint: "A network that spans a large geographical area."
    },
    {
        word: "tcp",
        hint: "Transmission Control Protocol; fundamental protocols for the Internet."
    },
    {
        word: "bgp",
        hint: "Border Gateway Protocol; used to exchange routing information between systems on the internet."
    },
    {
        word: "icmp",
        hint: "Internet Control Message Protocol; used for error messages and operational information queries."
    },
    {
        word: "qos",
        hint: "Technique to manage network resources by prioritizing certain types of data."
    },
    {
        word: "proxy",
        hint: "Server that acts as an intermediary for requests from clients."
    },
    {
        word: "switching",
        hint: "Process of moving packets from one port to another within a network."
    },
    {
        word: "routing",
        hint: "Process of selecting paths in a network along which to send data."
    },
    {
        word: "throughput",
        hint: "The amount of data that can be processed in a given amount of time."
    },
    {
        word: "broadcast",
        hint: "Transmission of data to all devices in a network."
    },
    {
        word: "unicast",
        hint: "Transmission of data to a single specific recipient."
    },
    {
        word: "multicast",
        hint: "Transmission of data to multiple specific recipients."
    },
    {
        word: "network",
        hint: "Group of interconnected devices for sharing resources and information."
    },
    {
        word: "bridge",
        hint: "Device that connects two or more network segments."
    },
    {
        word: "vlan",
        hint: "Virtual LAN; separates network traffic for security and efficiency."
    },
    {
        word: "san",
        hint: "Storage Area Network; provides access to consolidated storage."
    },
    {
        word: "nas",
        hint: "Network Attached Storage; dedicated file storage that can be accessed by multiple devices."
    },
    {
        word: "hub",
        hint: "Device that connects multiple Ethernet devices, making them act as a single network segment."
    },
    {
        word: "mpls",
        hint: "Multiprotocol Label Switching; directs data from one network node to the next based on short path labels."
    },
    {
        word: "mtu",
        hint: "Maximum Transmission Unit; the size of the largest packet that a network protocol can transmit."
    },
    {
        word: "latency",
        hint: "Time delay experienced in a system."
    },
    {
        word: "wifi",
        hint: "Wireless networking technology that uses radio waves to provide high-speed internet and network connections."
    },
    {
        word: "ssid",
        hint: "Service Set Identifier; the name of a wireless network."
    },
    {
        word: "radius",
        hint: "Remote Authentication Dial-In User Service; networking protocol that provides centralized authentication."
    },
    {
        word: "ldap",
        hint: "Lightweight Directory Access Protocol; used for accessing and maintaining distributed directory information services."
    },
    {
        word: "ssl",
        hint: "Secure Sockets Layer; standard security technology for establishing an encrypted link."
    },
    {
        word: "tls",
        hint: "Transport Layer Security; successor to SSL for securing data transmitted over a network."
    },
    {
        word: "tunneling",
        hint: "A method of using an internetwork infrastructure to transfer data for one network over another network."
    },
    {
        word: "technology",
        hint: "The application of scientific knowledge for practical purposes."
    },
    {
        word: "ssh",
        hint: "Secure Shell; protocol for securely accessing network services over an unsecured network."
    },
    {
        word: "snmp",
        hint: "Simple Network Management Protocol; used for network management."
    },
    {
        word: "wep",
        hint: "Wired Equivalent Privacy; security algorithm for IEEE 802.11 wireless networks."
    },
    {
        word: "poe",
        hint: "Power over Ethernet; allows an Ethernet cable to carry electrical power."
    },
    {
        word: "hotspot",
        hint: "A physical location where people can access the internet, typically using Wi-Fi."
    },
    {
        word: "dmz",
        hint: "Demilitarized Zone; a physical or logical subnetwork that contains and exposes an organization's external-facing services."
    },
    {
        word: "ddos",
        hint: "Distributed Denial of Service; a cyber-attack where multiple systems flood the bandwidth or resources of a targeted system."
    },
    {
        word: "repeater",
        hint: "A device that receives and retransmits a signal to extend its range."
    },
    {
        word: "traceroute",
        hint: "A network diagnostic tool used to track the pathway taken by a packet on an IP network."
    },
    {
        word: "multihoming",
        hint: "A technique where a host or a network is connected to more than one network."
    },
    {
        word: "redundancy",
        hint: "The duplication of critical components to increase reliability."
    },
    {
        word: "failover",
        hint: "The process of switching to a standby system when the primary system fails."
    },
    {
        word: "nac",
        hint: "Network Access Control; a security solution that controls access to a network."
    },
    {
        word: "ids",
        hint: "Intrusion Detection System; used to detect and prevent security breaches."
    },
    {
        word: "qoe",
        hint: "Quality of Experience; a measure of a user's experiences with a service."
    },
    {
        word: "bottleneck",
        hint: "A point of congestion in a network causing slower data transmission."
    },
    {
        word: "gre",
        hint: "Generic Routing Encapsulation; a tunneling protocol developed by Cisco."
    },
    {
        word: "ipsec",
        hint: "Internet Protocol Security; a suite of protocols to secure internet protocol communications."
    },
    {
        word: "tropical",
        hint: "Relating to or situated in the region between the Tropic of Cancer and the Tropic of Capricorn."
    },
    {
        word: "man",
        hint: "Metropolitan Area Network; a network that spans a city or large campus."
    },
    {
        word: "igp",
        hint: "Interior Gateway Protocol; used for exchanging routing information within an autonomous system."
    },
    {
        word: "egp",
        hint: "Exterior Gateway Protocol; used for exchanging routing information between different autonomous systems."
    },
];