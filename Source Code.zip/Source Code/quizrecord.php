<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="logo.jpeg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
    />
    <title>Edusphere-Quiz Record(Topic)</title>
    <link rel="stylesheet" href="quizrecordstyle.css">
</head>

<body>
    <div class="table">
        <div class="table-header">
            <p>Quiz Record</p>
            <div>
                <input placeholder="Search....."/>
            </div>
        </div>
        <div class="table-section">
            <table>
                <thead>
                    <tr>
                        <th>No. <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Name <span class="icon-arrow">&UpArrow;</span></th>
                        <th>TP Number <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Class <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Date <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Quiz <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Result</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Sean</td>
                        <td>TP123456</td>
                        <td>Class A</td>
                        <td>23/05/2024</td>
                        <td>Quiz 1</td>
                        <td>
                        <a href="result1.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Ivan</td>
                        <td>TP567899</td>
                        <td>Class C</td>
                        <td>01/05/2024</td>
                        <td>Quiz 3</td>
                        <td>
                        <a href="result2.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Aaron</td>
                        <td>TP937391</td>
                        <td>Class B</td>
                        <td>23/04/2024</td>
                        <td>Quiz 2</td>
                        <td>
                        <a href="result3.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>    
                        </td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>Renee</td>
                        <td>TP363812</td>
                        <td>Class A</td>
                        <td>01/04/2024</td>
                        <td>Quiz 1</td>
                        <td>
                        <a href="result4.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>Edmund</td>
                        <td>TP654321</td>
                        <td>Class B</td>
                        <td>18/03/2024</td>
                        <td>Quiz 3</td>
                        <td>
                        <a href="result5.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>Justin</td>
                        <td>TP787234</td>
                        <td>Class D</td>
                        <td>15/03/2024</td>
                        <td>Quiz 1</td>
                        <td>
                        <a href="result6.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td>John</td>
                        <td>TP456789</td>
                        <td>Class B</td>
                        <td>10/02/2024</td>
                        <td>Quiz 1</td>
                        <td>
                        <a href="result7.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>8</td>
                        <td>Jack</td>
                        <td>TP748203</td>
                        <td>Class D</td>
                        <td>10/04/2024</td>
                        <td>Quiz 3</td>
                        <td>
                        <a href="result8.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>9</td>
                        <td>Alex</td>
                        <td>TP723648</td>
                        <td>Class A</td>
                        <td>31/03/2024</td>
                        <td>Quiz 1</td>
                        <td>
                        <a href="result9.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>10</td>
                        <td>Jordan</td>
                        <td>TP984941</td>
                        <td>Class C</td>
                        <td>29/02/2024</td>
                        <td>Quiz 2</td>
                        <td>
                        <a href="result10.php"> 
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <!-- <tr>
                        <td>11</td>
                        <td>Abigail</td>
                        <td>TP667432</td>
                        <td>Class B</td>
                        <td>29/05/2024</td>
                        <td>Quiz 2</td>
                        <td>
                        <a href="Result/">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>12</td>
                        <td>Emily</td>
                        <td>TP723492</td>
                        <td>Class D</td>
                        <td>30/04/2024</td>
                        <td>Quiz 1</td>
                        <td>
                        <a href="Result/">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>13</td>
                        <td>Chloe</td>
                        <td>TP749309</td>
                        <td>Class A</td>
                        <td>29/01/2024</td>
                        <td>Quiz 1</td>
                        <td>
                        <a href="Result/"> 
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>14</td>
                        <td>Lucas</td>
                        <td>TP983424</td>
                        <td>Class C</td>
                        <td>01/06/2024</td>
                        <td>Quiz 3</td>
                        <td>
                        <a href="Result/">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>15</td>
                        <td>Isaac</td>
                        <td>TP571484</td>
                        <td>Class B</td>
                        <td>23/01/2024</td>
                        <td>Quiz 2</td>
                        <td>
                        <a href="Result/">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr> -->
                </tbody>
            </table>
        </div>
    </div>

    <script src="quizrecordscript.js"></script>
</body>

</html>