<?php
// dashboard.php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Ensure that the session contains the name of the user
$name = isset($_SESSION['name']) ? htmlspecialchars($_SESSION['name'], ENT_QUOTES, 'UTF-8') : 'User';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="logo.jpeg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
    />
    <title>Edusphere</title>
    <link rel="stylesheet" href="css/about_us.css">
</head>

<body>
    <main class="main">
    <a href="student_dashboard.php">
      <div class="table-header">
        <p>About Us</p>
      </div>
    </a>  
         
    <div class="wrapper">

      <div class="infobox1">
        <div class="mission">
          Mission
        </div>
        <div class="underline"></div>
        <div class="content">
          We strive to develop and have consistent improvement our gamified e-learning platform for networking courses by incorporating engaging elements such as scored quizzes and games based around networking with high-quality educational content, we strive to boost student motivation, focus, and practical skills. Our platform improves with each feedback and needs, providing an effective learning environment that prepares students for real-world challenges in technology-related fields.
        </div>
      </div>

      <div class="infobox2">
        <div class="vision">
          Vision
        </div>
        <div class="underline"></div>
        <div class="content">
          Our vision is to revolutionize traditional education through technology, bringing an engaging and interactive learning experience that enhances student understanding and participation. We aim to make high-quality education accessible to everyone throughout our platform by providing free access.
        </div>
      </div>

      <div class="infobox3">
        <div class="about_us">
          About Us
        </div>
        <div class="underline"></div>
        <div class="content">
          Our team is committed to transforming education through the usage of our innovative e-learning platform, Edusphere. Our goal is to make difficult topics like networking more interesting and approachable by gamifying the learning process. Our platform is designed for technology-related courses where networking is an essential component, such information technology and software engineering. We understand the importance of connecting computer systems for global resource access, data sharing, and communication, which is essential for both corporate environments and educational institutions.
        </div>
      </div>

    </div>

    </main>

    <script src="script2.js"></script>
</body>

</html>
