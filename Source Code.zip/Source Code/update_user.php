<?php
$servername = "localhost";
$username = "root";  // your phpMyAdmin username
$password = "";      // your phpMyAdmin password
$lecturer_dbname = "lecturer_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $lecturer_dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    
    if ($action === 'update') {
        $id = $_POST['id'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $birthday = $_POST['birthday'];
        $password = $_POST['password'];

        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $sql = "UPDATE users SET username=?, email=?, date_of_birth=?, password=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssi", $username, $email, $birthday, $hashed_password, $id);
        } else {
            $sql = "UPDATE users SET username=?, email=?, date_of_birth=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssi", $username, $email, $birthday, $id);
        }

        if ($stmt->execute()) {
            echo "Update successful";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } elseif ($action === 'delete') {
        $id = $_POST['id'];
        $sql = "DELETE FROM users WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo "User deleted successfully";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>
