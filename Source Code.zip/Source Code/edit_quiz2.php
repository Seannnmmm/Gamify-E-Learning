<?php 
  require_once("include/conn.php");

  $query_topic = "SELECT * FROM quiz_topic";
  $result_topic = mysqli_query($conn,$query_topic);
  
  $query_question = "SELECT * FROM quiz_question";
  $result_question = mysqli_query($conn,$query_question);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Update Topic</title>
  <link rel="stylesheet" href="css/edit_quiz.css">
</head>

<body>

<a href="lecturer_dashboard.php">
  <div class="table-header">
      <p>Edit Quiz</p>
  </div>
</a>

  <form autocomplete="off" onsubmit="alert('form submitted!')" action="editQuizProcess.php" method="POST">          
    <br>
    <div class="edit_form">
      <div class="content">

        <label id="question" for="question">Question <i>(required)</i> </label><br>
        <select name="questionselection" id="question_select">
          <?php //fetch and display question
            while($row = mysqli_fetch_assoc($result_question)) {
              $id = $row['topic_id'];
              $question = $row['question_text'];
              echo "<option value='$id'>Topic $id - $question </option>";
            }
          ?>
        </select> <br>
        <input type="text" name="question" required>

      <br>

      <div>
        <label for="choice1">Choice 1 <i>(required)</i></label><br>
        <input type="text" name="choice1" value="" required size="70">
      </div>

      <br>

      <div>
        <label for="choice2">Choice 2 <i>(required)</i></label><br>
        <input type="text" name="choice2" value="" required size="70">
      </div>

      <br>
      
      <div>
        <label for="choice3">Choice 3 <i>(required)</i></label><br>
        <input type="text" name="choice3" value="" required size="70">
      </div>

      <br>

      <div>
        <label for="choice4">Choice 4 <i>(required)</i></label><br>
        <input type="text" name="choice4" value="" required size="70">
      </div>

      <br>

      <div>
        <label for="answer">Answer <i>(required)</i></label><br>
        <input type="text" name="answer" value="" required size="70">
      </div>

      <br>
    
      <div>
        <input id="reset" type="reset">
      </div>

      <br>

      <div>
        <button id="submit" type="submit">Submit</button>
      </div>

      </div>
      </div>
    </div>
    
  </form>



</body>
</html>
