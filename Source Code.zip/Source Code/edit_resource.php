<?php 
  require_once("include/conn.php");

  $query_resource = "SELECT * FROM resource";
  $result_resource = mysqli_query($conn,$query_resource);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Update Topic</title>
  <link rel="stylesheet" href="css/edit_resource.css">
</head>

<body>

<a href="lecturer_dashboard.php">
  <div class="table-header">
      <p>Edit Resource</p>
  </div>
</a>

  <form autocomplete="off" onsubmit="alert('form submitted!')" action="editResourceProcess.php" method="POST">

    <div class="edit_form">
      <div class="content">

        <label for="title_select">Title <i>(required)</i> </label><br>
        <select name="titleselection" id="titledrop">
            <?php
                //fetch and display note title
                    while($row = mysqli_fetch_assoc($result_resource)) {
                        $topicid = $row['topic_id'];
                        $title = $row['title'];
                        echo "<option value='$topicid'>Topic $topicid .$title</option>";
                    }
            ?>
        </select> <br>
        <input type="text" name="title" required>
      </div>

      <br>

      <div class="content">

        <label for="question">Note <i>(required)</i> </label><br>
        <input type="text" name="note"  required>
        <br><br>

        <div>
          <input id="reset" type="reset">
        </div><br>
        
        <div>
          <input id="submit" type="submit">
        </div>

      </div>
        
      </div>
      </div>
    </div>
    
  </form>

</body>
</html>
