let words = [
    {
        word: "router",
        hint: "Device that forwards data packets between computer networks."
    },
    {
        word: "switch",
        hint: "Networking device that connects devices within a LAN."
    },
    {
        word: "firewall",
        hint: "Security system that controls incoming and outgoing network traffic."
    },
    {
        word: "protocol",
        hint: "Set of rules governing data communication."
    },
    {
        word: "bandwidth",
        hint: "The maximum rate of data transfer across a network."
    },
    {
        word: "latency",
        hint: "Time it takes for a data packet to travel from source to destination."
    },
    {
        word: "topology",
        hint: "The arrangement of various elements in a computer network."
    },
    {
        word: "ethernet",
        hint: "A widely used LAN technology."
    },
    {
        word: "modem",
        hint: "Device that modulates and demodulates signals for data transmission."
    },
    {
        word: "ping",
        hint: "Network utility used to test reachability of a host."
    },
    {
        word: "proxy",
        hint: "Server that acts as an intermediary for requests from clients seeking resources from other servers."
    },
    {
        word: "subnet",
        hint: "A smaller network within a larger network."
    },
    {
        word: "gateway",
        hint: "A node that routes traffic from a workstation to the outside network."
    },
    {
        word: "nat",
        hint: "Technique used to modify network address information in packet headers."
    },
    {
        word: "dns",
        hint: "System that translates domain names to IP addresses."
    },
    {
        word: "dhcp",
        hint: "Protocol that automatically assigns IP addresses to devices on a network."
    },
    {
        word: "vpn",
        hint: "Service that encrypts your internet connection for privacy."
    },
    {
        word: "packet",
        hint: "Formatted unit of data carried by a packet-switched network."
    },
    {
        word: "udp",
        hint: "Protocol used for low-latency and loss-tolerating connections."
    },
    {
        word: "socket",
        hint: "Endpoint for sending or receiving data in a network."
    },
    {
        word: "port",
        hint: "Logical access point for communication in a network."
    },
    {
        word: "isp",
        hint: "Company that provides internet access to users."
    },
    {
        word: "wireless",
        hint: "Networking technology that allows devices to communicate without cables."
    },
]