let questions = [
    {
        numb: 1,
        question: "What are ‘firewalls’?",
        answer: "C. A firewall is a network security system responsible for managing network traffic.",
        options: [
            "A. A firewall is a protocol security system responsible for managing network traffic.",
            "B. It uses a set of security rules to give remote access and content filtering.",
            "C. A firewall is a network security system responsible for managing network traffic.",
            "D. It is not uses a set of security rules to prevent remote access and content filtering."
        ]
    },
    {
        numb: 2,
        question: "How does a firewall work?",
        answer: "B. The firewall ‘listens’ for what information packets are trying to leave or enter the computer system.",
        options: [
            "A. The firewall accept for what information packets are trying to leave or enter the computer system.",
            "B. The firewall ‘listens’ for what information packets are trying to leave or enter the computer system.",
            "C. The firewall without follow for what information packets are trying to leave or enter the computer system.",
            "D. The firewall uses what information packets are trying to leave or enter the computer system."

        ]
    },
    {
        numb: 3,
        question: "What are NOT the different ways to exchange data?",
        answer: "D. Extra Full-duplex",
        options: [
            "A. Simplex",
            "B. Half-duplex",
            "C. Full-duplex",
            "D. Extra Full-duplex"
        ]
    },
    {
        numb: 4,
        question: "What are routers?",
        answer: "A. A router is a computer and networking device that forwards data packets between computer networks, including internetworks such as the global Internet.",
        options: [
            "A. A router is a computer and networking device that forwards data packets between computer networks, including internetworks such as the global Internet.",
            "B. A router[a] is a computer and networking device that recieve data packets between computer networks, including internetworks such as the global Internet.",
            "C. A router[a] is a computer and networking device that forwards data packets between computer networks, excluding internetworks such as the global Internet.",
            "D. A router[a] is a computer and networking device that forwards data packets between router, including internetworks such as the global Internet."
        ]
    },
    {
        numb: 5,
        question: "What are NOT the criteria for the best path selection of a router?",
        answer: "C. Maximum AD (administrative distance)",
        options: [
            "A. Longest prefix match",
            "B. Minimum AD (administrative distance)",
            "C. Maximum AD (administrative distance)",
            "D. Lowest metric value"
        ]
    },
    {
        numb: 6,
        question: "How can you secure a computer network?",
        answer: "B. Ensure firewalls are set and configured properly",
        options: [
            "A. Update password once",
            "B. Ensure firewalls are set and configured properly",
            "C. Install a unreliable antivirus program",
            "D. Not update firewall regularly"
        ]
    },
    {
        numb: 7,
        question: "What is TELNET?",
        answer: "D. TELNET is a client-service protocol on the internet or local area network, allowing a user to log on to a remote device and have access to it.",
        options: [
            "A. TELNET is a client-service procedure on the internet or local area network, allowing a user to log on to a remote device and have access to it.",
            "B. TELNET is a client-service protocol on the internet or foreign area network, allowing a user to log on to a remote device and have access to it.",
            "C. TELNET is a client-service protocol on the internet or local area network, not allowing a user to log on to a remote device and have access to it.",
            "D. TELNET is a client-service protocol on the internet or local area network, allowing a user to log on to a remote device and have access to it."
        ]
    },
    {
        numb: 8,
        question: "Which is NOT the uses of the Hamming code?",
        answer: "D. Router",
        options: [
            "A. Modems",
            "B. Satellites",
            "C. Computer Memory",
            "D. Router"
        ]
    },
    {
        numb: 9,
        question: "What are proxy servers?",
        answer: "B. Proxy servers prevent external users from identifying the IP addresses of an internal network.",
        options: [
           "A. Proxy servers prevent internal users from identifying the IP addresses of an external network.",
            "B. Proxy servers prevent external users from identifying the IP addresses of an internal network.",
            "C. Proxy servers access external users from identifying the IP addresses of an internal network.",
            "D. Proxy servers prevent external users from confirming the IP addresses of an internal network."
        ]
    },
    {
        numb: 10,
        question: "How do they protect computer networks?",
        answer: "A. They make a network virtually invisible to external users, who cannot identify the physical location of a network.",
        options: [
           "A. They make a network virtually invisible to external users, who cannot identify the physical location of a network.",
            "B. They make a network virtually invisible to internal users, who cannot identify the physical location of a network.",
            "C. They make a network virtually invisible to external users, who can identify the physical location of a network.",
            "D. They make a network virtually invisible to internal users, who can identify the physical location of a network."
        ]
    },
];