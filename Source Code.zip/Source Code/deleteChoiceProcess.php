<?php

require_once("include/conn.php");

$id = $_POST["choicedeleteid"];


$query = "DELETE FROM quiz_choice WHERE _id = $id";


if (mysqli_query($conn, $query)) {
    echo "Topic with ID $id has been deleted successfully.";
} else {
    echo "Error deleting topic: " . mysqli_error($conn);
}

?>