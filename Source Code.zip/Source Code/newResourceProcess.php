<?php

require_once("include/conn.php");

// Taking 6 values from the form data(input)
$topic_id = $_POST["topic"];
$title = $_POST["title"];
$note = $_POST["note"];


$sql_resource = "INSERT INTO resource (title, note, topic_id)

        VALUES (?,?,?)"; //placeholder for prepared statement to avoid sql injection
         
//create prepare statement for data 
$stmt_resource = mysqli_stmt_init($conn);

// pass object into connection 
if (!mysqli_stmt_prepare($stmt_resource,$sql_resource)){
    die('Statement preparation Failed!' . mysqli_error($conn));
}

//binding data into placeholders
mysqli_stmt_bind_param($stmt_resource, "ssi",
                                $title,
                                $note,
                                $topic_id);

mysqli_stmt_execute($stmt_resource);

echo"Record saved.";

header('Location: https://localhost/SDP_Compile/Final/addresource.php', true, 301); //301 = perm redirect, 302 = temp redirect

exit;