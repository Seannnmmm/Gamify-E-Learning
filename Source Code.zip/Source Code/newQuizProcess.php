<?php

require_once("include/conn.php");

// Taking 6 values from the form data(input)
$topic_id = $_POST["topic"];
$question = $_POST["question"];
$answer = $_POST["answer"];
$choice1 = $_POST["choice1"];
$choice2 = $_POST["choice2"];
$choice3 = $_POST["choice3"];
$choice4 = $_POST["choice4"];
     

$sql_question = "INSERT INTO quiz_question (question_text, topic_id)

        VALUES (?,?)"; //placeholder for prepared statement to avoid sql injection
         
//create prepare statement for data 
$stmt_question = mysqli_stmt_init($conn);

// pass object into connection 
if (!mysqli_stmt_prepare($stmt_question,$sql_question)){
    die('Statement preparation Failed!' . mysqli_error($conn));
}

//binding data into placeholders
mysqli_stmt_bind_param($stmt_question, "si",
                                $question,
                                $topic_id);

mysqli_stmt_execute($stmt_question);

$question_id = mysqli_insert_id($conn);

$sql_choice = "INSERT INTO quiz_choice (choice1, choice2, choice3, choice4, answer, question_id)
         VALUES (?,?,?,?,?,?)";

$stmt_choice = mysqli_stmt_init($conn);

if (!mysqli_stmt_prepare($stmt_choice,$sql_choice)){
    die('Statement preparation Failed!' . mysqli_error($conn));
}
               
mysqli_stmt_bind_param($stmt_choice, "sssssi",
                                $choice1,
                                $choice2,
                                $choice3,
                                $choice4,
                                $answer,
                                $question_id);

mysqli_stmt_execute($stmt_choice);

echo"Record saved.";

header('Location: https://localhost/SDP_Compile/Final/new_quiz.php', true, 301); //301 = perm redirect, 302 = temp redirect
echo"Record saved.";
exit;