<?php
// dashboard.php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Ensure that the session contains the name of the user
$name = isset($_SESSION['name']) ? htmlspecialchars($_SESSION['name'], ENT_QUOTES, 'UTF-8') : 'User';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Quiz</title>
    <link rel="stylesheet" href="css/manage_resource.css">
</head>
<body>

<main class="main">
<a href="lecturer_dashboard.php">
  <div class="table-header">
      <p>Edit Resource</p>
  </div>
</a>

    <h1 class="h1">MANAGE RESOURCE</h1>
    <div class="underline"></div>

    <div id="wrapper">

        <a href="addresource.php">
            <div class="box1">
                <div>
                <img id="plus" src="Image/Plus_Sign-removebg-preview.png" alt="">
                <b>NEW RESOURCE</b>
                </div>
            </div>  
        </a>

        <a href="edit_resource.php">
            <div class="box2">
                <div>
                    <img id="pencil" src="Image/pencil-removebg-preview.png" alt="">
                    <b>EDIT RESOURCE</b>
                </div>
            </div>
        </a>    
            
    </div>
    </main>
</body>
</html>