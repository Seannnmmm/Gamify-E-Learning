<?php

session_start();
include "include/conn.php";

$selected = $_POST["titleselection"];
$note = $_POST["note"];
$title = $_POST["title"];


$sql_title = "UPDATE resource SET title = '$title' WHERE resource_id = '$selected'";

$sql_note = "UPDATE resource SET note = '$note' WHERE resource_id = '$selected'";

// echo $sql;
$result = mysqli_query($conn, $sql_title);

$result2 = mysqli_query($conn,$sql_note);

echo "Edit successful!"
?>


