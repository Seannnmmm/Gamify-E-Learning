<?php

require_once("include/conn.php");

$query_topic = "SELECT * FROM resource";

$result_topic = mysqli_query($conn,$query_topic);

$query_note = "SELECT * FROM resource";

$result_note = mysqli_query($conn,$query_topic);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Topic Quiz</title>
    <link rel="stylesheet" href="css/topic_quiz2.css">
</head>

<body>

<a href="student_dashboard.php">
  <div class="table-header">
      <p>View Resource</p>
  </div>
</a>
    <div class="bigbox">

    <button class="accordion">
        <?php $row_topic = mysqli_fetch_assoc($result_topic) ?>
        <?php echo $row_topic['title']; ?></button>
    <ul class="panel">

            <div class="topicbox">
                <li>
                    <?php $row_note = mysqli_fetch_assoc($result_note) ?>
                    <?php echo $row_note['note']; ?>

                </li>
            </div>
    
    </ul>

    <button class="accordion">
        <?php $row_topic = mysqli_fetch_assoc($result_topic) ?>
        <?php echo $row_topic['title']; ?></button>
    <ul class="panel">

            <div class="topicbox">
                <li>
                    <?php $row_note = mysqli_fetch_assoc($result_note) ?>
                    <?php echo $row_note['note']; ?>

                </li>


            </div>
  
    </ul>

    <button class="accordion">
        <?php $row_topic = mysqli_fetch_assoc($result_note) ?>
        <?php echo $row_topic['title']; ?></button>
    <ul class="panel">
            <div class="topicbox">
                <li> 
                    <?php $row_note = mysqli_fetch_assoc($result_topic) ?>
                    <?php echo $row_note['note']; ?>
                </li>
    </ul>


    </div>
    
    <script src="topic_quiz.js"></script>
</body>

</html>