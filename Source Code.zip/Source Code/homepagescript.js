const profileDropdownList = document.querySelector(".profile-dropdown-list");
const btn = document.querySelector(".profile-dropdown-btn");

let classList = profileDropdownList.classList;

// this function display or hide profile dropdown lsit
const toggle = () => classList.toggle("active");

//hide dropdown list if user click outside dropdown button
window.addEventListener("click", function (e) {
    if (!btn.contains(e.target)) classList.remove("active");
});