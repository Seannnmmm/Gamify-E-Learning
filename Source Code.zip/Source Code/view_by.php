<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View By</title>
    <link rel="stylesheet" href="css/view_by.css">
</head>

<body>
    
<a href="lecturer_dashboard.php">
  <div class="table-header">
      <p>Quiz Category</p>
  </div>
</a>

    <div class="title"><b>VIEW BY</b></div>
    
    <div class="wrapper">
        <a href="extraexercise.php">
            <div class="box1">
                <img id="book" src="Image/book-removebg-preview.png" alt="">
                <b>Extra Exercise</b>
            </div>
        </a>
            
        <div class="vl"></div>
        
        <a href="topic_quiz2.php">
            <div class="box2">
                <img id="chat" src="Image/chat-removebg-preview.png" alt="">
                <b>Topic</b>
            </div>
        </a>
    </div>

</body>
</html>