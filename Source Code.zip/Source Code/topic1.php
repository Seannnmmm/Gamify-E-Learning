<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="logo.jpeg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
    />
    <title>Edusphere-Topic1</title>
    <link rel="stylesheet" href="topic1style.css">
</head>

<body>
    <main class="main">
         <nav class="navbar">
            <a href="student_dashboard.php" class="logo">
              <button>Edusphere</button>
            </a>
            <ul class="menu-bar">
                <li class="dropdown">
                  <a class="dropdown-text" href="student_dashboard.php">Home</a>
                </li>
                <li class="dropdown">
                  <a class="dropdown-text" href="#">Resources</a>
        
                  <ul class="menu resources">
                    <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Quiz
                      </a>
                      <ul class="sub-menu">
                        <li>
                          <a  target="_blank"  href="topic1.php">
                            <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                            Topic 1</a
                          >
                        </li>
                        <li>
                          <a  target="_blank" href="topic2.php">
                            <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                            Topic 2</a
                          >
                        </li>
                        <li>
                          <a  target="_blank" href="topic3.php">
                            <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                            Topic 3</a
                          >
                        </li>
                      </ul>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Game Learning <i class="fa-solid fa-angle-right arrow-right"></i>
                      </a>
                        <ul class="sub-menu">
                          <li>
                            <a  target="_blank"  href="scramble.php">
                              <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                              Word Scramble</a
                            >
                          </li>
                          <li>
                            <a  target="_blank"  href="Hangman.php">
                              <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                              Hangman</a
                            >
                          </li>
                        </ul>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Extra Exercise <i class="fa-solid fa-angle-right arrow-right"></i>
                      </a>
                        <ul class="sub-menu">
                          <li>
                            <a  target="_blank"  href="extraexercise.php">
                              <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                              Quiz Record</a
                            >
                          </li>
                        </ul>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Topic <i class="fa-solid fa-angle-right arrow-right"></i>
                      </a>
                        <ul class="sub-menu">
                          <li>
                            <a  target="_blank"  href="quizrecord.php">
                              <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                              Quiz Record</a
                            >
                          </li>
                        </ul>
                    </li>
                  </ul>
                </li>
                <li class="dropdown">
                  <a class="dropdown-text" href="#">Contact</a>
        
                  <ul class="menu contact">
                    <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Head Quater
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Email Address
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Contact Number
                      </a>
                    </li>
                  </ul>
                </li>
        
                <li class="dropdown">
                  <a class="dropdown-text" href="student_about_us.php">About</a>
                </li>
              </ul>

            <div class="profile-dropdown">
                <div onclick="toggle()" class="profile-dropdown-btn">
                  <div class="profile-img">
                    <i class="fa-solid fa-circle"></i>
                  </div>
        
                  <span
                    >Sean
                    <i class="fa-solid fa-angle-down"></i>
                  </span>
                </div>
        
                <ul class="profile-dropdown-list">
                  <li class="profile-dropdown-list-item">
                    <a href="#">
                      <i class="fa-regular fa-user"></i>
                      Edit Profile
                    </a>
                  </li>
        
                  <li class="profile-dropdown-list-item">
                    <a href="#">
                      <i class="fa-solid fa-sliders"></i>
                      Settings
                    </a>
                  </li>
        
                  <li class="profile-dropdown-list-item">
                    <a href="#">
                      <i class="fa-regular fa-circle-question"></i>
                      Help & Support
                    </a>
                  </li>
                  <hr />
        
                  <li class="profile-dropdown-list-item">
                    <a href="student_dashboard.php">
                      <i class="fa-solid fa-arrow-right-from-bracket"></i>
                      Log out
                    </a>
                  </li>
                </ul>
              </div>
            </nav>

         <div class="container">
            <section class="quiz-section">
                <div class="quiz-box">
                    <h1>Edusphere Quiz</h1>
                    <div class="quiz-header">
                        <span>Networks and Networking</span>
                        <span class="header-score">Score: 0 / 10</span>
                    </div>

                    <h2 class="question-text">What is a network?</h2>

                    <div class="option-list">
                        <!-- <div class="option">
                            <span>A. A network consists of two or more separate devices linked together such that they can communicate.</span>
                        </div>
                        <div class="option">
                            <span>B. A network consists of only one devicethat they can communicate.</span>
                        </div>
                        <div class="option">
                            <span>C. A network consists of two or more separate devices are not linked together such that they can communicate.</span>
                        </div>
                        <div class="option">
                            <span>D. A network consists of two or more separate devices linked together but they cannot communicate.</span>
                        </div> -->
                    </div>

                    <div class="quiz-footer">
                        <span class="question-total">1 of 10 Questions</span>
                        <button class="next-btn">Next</button>
                    </div>
                </div>

                <div class="result-box">
                    <h2>Quiz Result!</h2>
                    <div class="percentage-container">
                        <div class="circular-progress">
                            <span class="progress-value">0%</span>
                        </div>

                        <span class="score-text">Your Score 0 out of 10</span>
                    </div>

                    <div class="buttons">
                        <button class="tryAgain-btn">Try Again</button>
                        <button class="goHome-btn">Go To Home</button>
                    </div>
                </div>
            </section>

            <section class="home">
                <div class="home-content">
                    <h1>Quiz</h1>
                    <p>Welcome to Edusphere Quiz Session! Ready to test my knowledge and have some fun — Let's start the quiz!</p>
                    <button class="start-btn">Start Quiz</button>
                </div>
            </section>
        </div>
    </main>

    <div class="popup-info">
        <h2>Quiz Guide</h2>
        <span class="info">1. This quiz shall consist 10 questions.</span>
        <span class="info">2. Once you select your answer, it can't be undone.</span>
        <span class="info">3. You'll get points on the basis of your correct answer.</span>
        <span class="info">4. You can't exit from the Quiz while you're answering.</span>
        <span class="info">5. There are not time limit for this quiz.</span>

        <div class="btn-group">
            <button class="info-btn exit-btn">Exit Quiz</button>
            <a href="#" class="info-btn continue-btn">Continue</a>
        </div>
    </div>

    <script src="topic1question.js"></script>
    <script src="topic1script.js"></script>
</body>

</html>