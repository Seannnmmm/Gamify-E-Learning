<?php
// login.php
$servername = "localhost";
$username = "root";  // your phpMyAdmin username
$password = "";      // your phpMyAdmin password
$admin_dbname = "admin_db";
$student_dbname = "student_db";
$lecturer_dbname = "lecturer_db";

// Create connections
$admin_conn = new mysqli($servername, $username, $password, $admin_dbname);
$student_conn = new mysqli($servername, $username, $password, $student_dbname);
$lecturer_conn = new mysqli($servername, $username, $password, $lecturer_dbname);

// Check connections
if ($admin_conn->connect_error) {
    die("Connection failed: " . $admin_conn->connect_error);
}
if ($student_conn->connect_error) {
    die("Connection failed: " . $student_conn->connect_error);
}
if ($lecturer_conn->connect_error) {
    die("Connection failed: " . $lecturer_conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $user_found = false;

    // Check admin database
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $admin_conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            session_start();
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $row['role'];
            $_SESSION['role_id'] = $row['role_id'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['date_of_birth'] = $row['date_of_birth'];
            $_SESSION['name'] = $row['name'];

            header("Location: admin_dashboard.php");
            exit();
        } else {
            echo "Invalid password.";
            exit();
        }
    }

    // Check lecturer database
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $lecturer_conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            session_start();
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $row['role'];
            $_SESSION['role_id'] = $row['role_id'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['date_of_birth'] = $row['date_of_birth'];
            $_SESSION['name'] = $row['name'];

            header("Location: lecturer_dashboard.php");
            exit();
        } else {
            echo "Invalid password.";
            exit();
        }
    }

    // Check student database
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $student_conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            session_start();
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $row['role'];
            $_SESSION['role_id'] = $row['role_id'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['date_of_birth'] = $row['date_of_birth'];
            $_SESSION['name'] = $row['name'];

            header("Location: student_dashboard.php");
            exit();
        } else {
            echo "Invalid password.";
            exit();
        }
    }

    echo "No user found with this username.";
    $admin_conn->close();
    $lecturer_conn->close();
    $student_conn->close();
}
?>
