<?php

require_once('include/conn.php');
$query = "select * from quiz_topic";
$result = mysqli_query($conn,$query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/view_result.css">
</head>
<body>

    <div class="wrapper1">
        <div class="topic">
            <b>
                <?php $row = mysqli_fetch_assoc($result) ?>
                <?php echo $row['topic_name'] ?>
            </b>
        </div>
        <div class="underline"></div>
    </div>
    
    <div class="studentbox">
        <div class="score">
            9<br>/<br>10
        </div>
        <div class="check">
            <b>
                Check Result
            </b>
        </div>
        <div class="detailbox">
            <b>
                <ul class="studentdetails">
                    <li>Name</li>
                    <li>ID</li>
                    <li>Class</li>
                </ul>
            </b>
        </div>
    </div>
    
    <div class="studentbox">
        <div class="score">
            9<br>/<br>10
        </div>
        <div class="check">
            <b>
                Check Result
            </b>
        </div>
        <div class="detailbox">
            <b>
                <ul class="studentdetails">
                    <li>Name</li>
                    <li>ID</li>
                    <li>Class</li>
                </ul>
            </b>
        </div>
    </div>
    
    <div class="studentbox">
        <div class="score">
            9<br>/<br>10
        </div>
        <div class="check">
            <b>
                Check Result
            </b>
        </div>
        <div class="detailbox">
            <b>
                <ul class="studentdetails">
                    <li>Name</li>
                    <li>ID</li>
                    <li>Class</li>
                </ul>
            </b>
        </div>
    </div>

    
</body>
</html>