<?php
// Database connection parameters
$servername = "localhost";
$username = "root";  // Replace with your MySQL username
$password = "";      // Replace with your MySQL password
$student_dbname = "student_db"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $student_dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$name = $_POST['name'];
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$date_of_birth = $_POST['date_of_birth'];
$role = 'student'; // Assuming the role is 'student'

// Generate a unique role_id based on the role
$sql_max_role_id = "SELECT MAX(role_id) AS max_id FROM users WHERE role='$role'";
$result = $conn->query($sql_max_role_id);
$row = $result->fetch_assoc();
$role_id = ($row['max_id'] !== null ? $row['max_id'] : 0) + 1;

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert data into users table
$sql_insert_user = "INSERT INTO users (name, username, password, email, date_of_birth, role, role_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql_insert_user);
$stmt->bind_param("ssssssi", $name, $username, $hashed_password, $email, $date_of_birth, $role, $role_id);

if ($stmt->execute()) {
    echo "<script>
            alert('Registration successful');
            window.location.href='login.html';
          </script>";
} else {
    echo "<script>
            alert('Error: " . $stmt->error . "');
          </script>";
}

// Close connections
$stmt->close();
$conn->close();
?>
