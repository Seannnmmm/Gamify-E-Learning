<?php

require_once("include/conn.php");

$id = $_POST["resourcedeleteid"];


$query = "DELETE FROM resource WHERE resource_id = $id";


if (mysqli_query($conn, $query)) {
    echo "Resource with ID $id has been deleted successfully.";
} else {
    echo "Error deleting resource: " . mysqli_error($conn);
}

?>