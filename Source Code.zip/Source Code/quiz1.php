<?php

require_once("include/conn.php");

$query_topic = "SELECT * FROM quiz_topic";

$result_topic = mysqli_query($conn,$query_topic);

$query_question = "SELECT question_text FROM quiz_question WHERE topic_id = 1";

$result_question = mysqli_query($conn, $query_question);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Topic 1</title>
    <link rel="stylesheet" href="css/quiz1.css">
</head>
<body>
<a href="lecturer_dashboard.php">
  <div class="table-header">
        <p>
            <?php $row_topic = mysqli_fetch_assoc($result_topic) ?>
            <?php echo $row_topic['topic_name']; ?>
        </p>
  </div>
</a>

    <button class="accordion">
        <?php $row_question = mysqli_fetch_assoc($result_question) ?>
        <?php echo $row_question['question_text']; ?>
    </button>
    <button class="accordion">
        <?php $row_question = mysqli_fetch_assoc($result_question) ?>
        <?php echo $row_question['question_text']; ?>
    </button>
    <button class="accordion">
        <?php $row_question = mysqli_fetch_assoc($result_question) ?>
        <?php echo $row_question['question_text']; ?>
    </button>
    <button class="accordion">
        <?php $row_question = mysqli_fetch_assoc($result_question) ?>
        <?php echo $row_question['question_text']; ?>
    </button>
    <button class="accordion">
        <?php $row_question = mysqli_fetch_assoc($result_question) ?>
        <?php echo $row_question['question_text']; ?>
    </button>
    <button class="accordion">
        <?php $row_question = mysqli_fetch_assoc($result_question) ?>
        <?php echo $row_question['question_text']; ?>
    </button>
    <button class="accordion">
        <?php $row_question = mysqli_fetch_assoc($result_question) ?>
        <?php echo $row_question['question_text']; ?>
    </button>
    <button class="accordion">
        <?php $row_question = mysqli_fetch_assoc($result_question) ?>
        <?php echo $row_question['question_text']; ?>
    </button>
    <button class="accordion">
        <?php $row_question = mysqli_fetch_assoc($result_question) ?>
        <?php echo $row_question['question_text']; ?>
    </button>
    
    <form class="bigtopic" action="deleteQuizProcess.php" method="POST">
      <div id="topic">
        <label class="label" for="resource_id"> Delete Question</label>
        <input id="input" type="text" name="deletequestion" placeholder="Enter Question Number"><br>
        <input type="submit" value="Delete">
            </div>
      </form>
</body>
</html>