<?php 
  require_once("include/conn.php");

  $query_topic = "SELECT * FROM quiz_topic";
  $result_topic = mysqli_query($conn,$query_topic);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Topic</title>
    <link rel="stylesheet" href="css/new_topic.css">
</head>
<body>
    
<a href="lecturer_dashboard.php">
  <div class="table-header">
      <p>Manage Quiz</p>
  </div>
</a>

    <div class="topicname">New Topic</div>
    <div class="underline"></div>
    
    <form onsubmit="alert('Form Submitted Successfully!')" action="newTopicProcess.php" method="POST">
        <div class="topicbox">
            <div class="box1">
                <label class="label" for="topic">Topic: </label>
                <input class="input" type="text" id="topic" name="topic" placeholder="Insert Topic Name">
            </div>
        </div>

        <button id="submit" type="submit">Submit New Topic</button>

    </form>

    <form class="edit_form2" action="deleteTopicProcess.php" method="POST">
      <div class="content2">
        <label for="question">Topic ID </label><br>
        <select name="questionselection" id="question_select">
          <?php //fetch and display question
            while($row = mysqli_fetch_assoc($result_topic)) {
              $id = $row['topic_id'];
              $topic = $row['topic_name'];
              echo "<option value='$id'>$topic </option>";
            }
          ?>
        </select> <br>

        <label class="label2" for="Topic_id">Delete Topic: </label><br>
        <input id="input" type="text" name="topicdeleteid" placeholder="Enter topic ID"><br>
        <br>
        <input id="delete" type="submit" value="Delete">
            </div>
      </form>

      <a href="add_new.php">
        <input id="back-btn" type="button" value="Back to Add New Topic/Quiz" class="back">
    </a>
</body>
</html>