<?php
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root";  // your phpMyAdmin username
$password = "";      // your phpMyAdmin password
$lecturer_dbname = "lecturer_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $lecturer_dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if admin is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Retrieve admin's role_id based on session
$role_id = isset($_SESSION['role_id']) ? $_SESSION['role_id'] : null;

// Initialize variables to hold admin information
$name = $username = $email = $date_of_birth = '';

// Fetch admin information
$sql = "SELECT name, username, email, date_of_birth FROM users WHERE role_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $role_id);
$stmt->execute();
$stmt->bind_result($name, $username, $email, $date_of_birth);
$stmt->fetch();
$stmt->close();

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Update admin information
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $date_of_birth = $_POST['date_of_birth'];

    $update_sql = "UPDATE users SET name = ?, username = ?, email = ?, date_of_birth = ? WHERE role_id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("ssssi", $name, $username, $email, $date_of_birth, $role_id);

    if ($update_stmt->execute()) {
        // Redirect with success message
        header("Location: view_lecturer_profile.php?success=true");
        exit();
    } else {
        $update_error = "Error: " . $update_stmt->error;
    }

    $update_stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Lecturer Profile</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');

        body {
            font-family: "Poppins", sans-serif;
            background-color: #4338ca;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 20px 40px 40px 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }
        h2, h3 {
            text-align: center;
            margin-bottom: 20px;
        }
        p {
            margin: 10px 0;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center; /* Align form items in center */
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"],
        input[type="date"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
        }
        input[type="submit"],
        .back-button {
            padding: 10px;
            background-color: #4338ca;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
            width: 48%; /* Adjust width for buttons */
            text-align: center;
            margin-bottom: 10px; /* Add margin between buttons */
            transition: .3s;
        }
        input[type="submit"]:hover,
        .back-button:hover {
            background-color: black;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>View Lecturer Profile</h2>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($name); ?></p>
        <p><strong>Username:</strong> <?php echo htmlspecialchars($username); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
        <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($date_of_birth); ?></p>
        
        <h3>Edit Profile</h3>
        <form action="view_lecturer_profile.php" method="post">
            <label for="name">Name:</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>" required>

            <label for="username">Username:</label>
            <input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>" required>

            <label for="email">Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>

            <label for="date_of_birth">Date of Birth:</label>
            <input type="date" name="date_of_birth" value="<?php echo htmlspecialchars($date_of_birth); ?>" required>

            <input type="submit" value="UPDATE">
            <a href="lecturer_dashboard.php" class="back-button">BACK</a>
        </form>
    </div>

    <?php if (isset($_GET['success']) && $_GET['success'] === 'true'): ?>
        <script>
            alert('Profile updated successfully');
        </script>
    <?php endif; ?>
</body>
</html>
