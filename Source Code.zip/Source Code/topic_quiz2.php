<?php

require_once("include/conn.php");

$query_topic = "SELECT * FROM quiz_topic";

$result_topic = mysqli_query($conn,$query_topic);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Topic Quiz</title>
    <link rel="stylesheet" href="css/topic_quiz2.css">
</head>

<body>

<a href="lecturer_dashboard.php">
  <div class="table-header">
      <p>Topic Quiz</p>
  </div>
</a>

    <div class="bigbox">


    <button class="accordion">January</button>
    <ul class="panel">
        <a href="quiz1.php">
            <div class="topicbox">
                <li>
                    <?php $row_topic = mysqli_fetch_assoc($result_topic) ?>
                    <?php echo $row_topic['topic_name']; ?>

                    <a href="quizrecord.php">
                    <div class="viewresult">
                        Result
                    </div>      
                    </a> 
                </li>
            </div>
        </a>
    </ul>

    <button class="accordion">February</button>
    <ul class="panel">
        <a href="quiz2.php">
            <div class="topicbox">
                <li>
                    <?php $row_topic = mysqli_fetch_assoc($result_topic) ?>
                    <?php echo $row_topic['topic_name']; ?>

                    <a href="quizrecord.php">
                    <div class="viewresult">
                        Result
                    </div>      
                    </a> 
                </li>


            </div>
        </a>
    </ul>

    <button class="accordion">March</button>
    <ul class="panel">
        <a href="quiz3.php">
            <div class="topicbox">
                <li>
                    <?php $row_topic = mysqli_fetch_assoc($result_topic) ?>
                    <?php echo $row_topic['topic_name']; ?>

                    <a href="quizrecord.php">
                    <div class="viewresult">
                        Result
                    </div>      
                    </a> 
                </li>


            </div>
        </a>
    </ul>


    </div>
    
    <script src="topic_quiz.js"></script>
</body>

</html>