<?php
// dashboard.php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Ensure that the session contains the name of the user
$name = isset($_SESSION['name']) ? htmlspecialchars($_SESSION['name'], ENT_QUOTES, 'UTF-8') : 'User';

require_once("include/conn.php");

$query = "SELECT * FROM quiz_topic";
$result = mysqli_query($conn,$query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Quiz</title>
    <link rel="stylesheet" href="css/new_quiz.css">
</head>

<body>

<main class="main">
<a href="lecturer_dashboard.php">
  <div class="table-header">
      <p>Manage Quiz</p>
  </div>
</a>

    <div class="head"><b>Create Quiz</b></div>
    <div class="underline"></div>

    <form autocomplete="off" onsubmit="alert('form submitted!')" action="newQuizProcess.php" method="POST">

            <div class="topic">
                <label id="topic" for="topic">Choose Topic:</label>
                <select name="topic" id="topic1">
                    <?php
                    //fetch and display
                        while($row = mysqli_fetch_assoc($result)) {
                            $id = $row['topic_id'];
                            $topic = $row['topic_name'];
                            echo "<option value='$id'>$topic</option>";
                        }
                    ?>
                </select>
            </div>

            <div id="quizbox">
                <div class="box1">
                    <div class="box2">
                        <label for="question"><b>Question: </b></label>
                        <input required type="text" id="question" name="question" size="70">
                    </div>
                </div>

                <div class="box1">
                    <div class="box2">
                        <label for="answer1"><b>Answer: </b></label>
                        <input required type="text" id="answer1" name="answer" size="70">
                    </div>
                </div>

                <br><br>
                
                <div class="box1">
                    <div class="box2">
                        <label for="choice1"><b>Choice 1: </b></label>
                        <input required type="text" id="choice1" name="choice1" size="70">
                    </div>
                </div>
                <br>
                <div class="box1">
                    <div class="box2">
                        <label for="choice2"><b>Choice 2: </b></label>
                        <input required type="text" id="choice2" name="choice2" size="70">
                    </div>
                </div>
                <br>
                <div class="box1">
                    <div class="box2">
                        <label for="choice3"><b>Choice 3: </b></label>
                        <input required type="text" id="choice3" name="choice3" size="70">
                    </div>
                </div>
                <br>
                <div class="box1">
                    <div class="box2">
                        <label for="choice4"><b>Choice 4: </b></label>
                        <input required type="text" id="choice4" name="choice4" size="70">
                    </div>
                </div>
            </div>
            <input type="submit" value="Finish!" id="submit" >
    </form>
    </main>
</body>
</html>