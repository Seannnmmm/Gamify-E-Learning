let questions = [
    {
        numb: 1,
        question: "What are Nodes?",
        answer: "D. Devices or data points on a more extensive network are known as nodes.",
        options: [
            "A. Only devices points on a more extensive network are known as nodes.",
            "B. Only data points on a more extensive network are known as nodes.",
            "C. Devices or data points on a more exclusive network are known as nodes.",
            "D. Devices or data points on a more extensive network are known as nodes."
        ]
    },
    {
        numb: 2,
        question: "What are Links?",
        answer: "A. A link is the physical and logical network component for interconnecting hosts or nodes in a network.",
        options: [
           "A. A link is the physical and logical network component for interconnecting hosts or nodes in a network.",
           "B. A link is just a physical network component for interconnecting hosts or nodes in a network.",
           "C. A link is just a logical network component for interconnecting hosts or nodes in a network.",
           "D. A link is the physical and logical network component for connecting hosts in a network."
        ]
    },
    {
        numb: 3,
        question: "What is SLIP?",
        answer: "C. SLIP, or Serial Line Interface Protocol, was developed during the early UNIX days and is used for remote access.",
        options: [
           "A. SLIP, or Serial Line Interface Procedure, was developed during the early UNIX days and is used for remote access.",
           "B. SLIP, or Serial Line Internal Protocol, was developed during the early UNIX days and is used for remote access.",
           "C. SLIP, or Serial Line Interface Protocol, was developed during the early UNIX days and is used for remote access.",
           "D. SLIP, or Serial Line Interface Protocol, was developed during the late UNIX days and is used for remote access."
        ]
    },
    {
        numb: 4,
        question: "What is Transmission Control Protocol / Internet Protocol (TCP/IP)?",
        answer: "C. It is a set of protocol layers designed to facilitate data exchange on heterogeneous networks.",
        options: [
           "A. It is a set of protocol layers designed to facilitate data interchange on homogeneous networks.",
           "B. It is a set of protocol layers designed to facilitate data exchange on homogeneous networks.",
           "C. It is a set of protocol layers designed to facilitate data exchange on heterogeneous networks.",
           "D. It is a set of procedure layers designed to facilitate data exchange on heterogeneous networks."
        ]
    },
    {
        numb: 5,
        question: "What are NOT the common software problems lead to network defects?",
        answer: "B. Procedure mismatch",
        options: [
            "A. Application conflicts",
            "B. Procedure mismatch",
            "C. Client-server problems",
            "D. Configuration error"
        ]
    },
    {
        numb: 6,
        question: "Why is encryption on a network necessary?",
        answer: "A. Encryption changes data from its original readable to unreadable format, thus ensuring network security.",
        options: [
            "A. Encryption changes data from its original readable to unreadable format, thus ensuring network security.",
            "B. Encryption changes data from its original unreadable to readable format, thus ensuring network security.",
            "C. Encryption changes data from its original readable format, thus ensuring network security.",
            "D. Encryption changes data from its original unreadable format, thus ensuring network security."
        ]
    },
    {
        numb: 7,
        question: "What is Routing Information Protocol (RIP)?",
        answer: "C. It is a simple protocol that exchanges information between the routers.",
        options: [
            "A. It is a complex protocol that exchanges information between the routers.",
            "B. It is a simple protocol that exchanges information between the modems.",
            "C. It is a simple protocol that exchanges information between the routers.",
            "D. It is a simple protocol that keeps information between the routers."
        ]
    },
    {
        numb: 8,
        question: "What is a peer-peer process?",
        answer: "A. The processes on each machine that communicate at a given layer are called the peer-peer process.",
        options: [
            "A. The processes on each machine that communicate at a given layer are called the peer-peer process.",
            "B. The processes on every machine that communicate at a given layer are called the peer-peer process.",
            "C. The processes on each machine that communicate at a certain layer are called the peer-peer process.",
            "D. The processes on each machine that interact at a given layer are called the peer-peer process."
        ]
    },
    {
        numb: 9,
        question: "Which are NOT the main elements of a protocol?",
        answer: "D. Data",
        options: [
           "A. Semantics",
           "B. Syntax",
           "C. Timing",
           "D. Data"
        ]
    },
    {
        numb: 10,
        question: "What is maximum length of the Thinnet Cable?",
        answer: "B. The maximum length of the Thinnet cable is 185 meters.",
        options: [
           "A. The maximum length of the Thinnet cable is 200 meters.",
           "B. The maximum length of the Thinnet cable is 185 meters.",
           "C. The maximum length of the Thinnet cable is 195 meters.",
           "D. The maximum length of the Thinnet cable is 180 meters.",
        ]
    },
];