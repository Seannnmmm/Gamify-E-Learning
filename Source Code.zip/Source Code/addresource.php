<?php

// dashboard.php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Ensure that the session contains the name of the user
$name = isset($_SESSION['name']) ? htmlspecialchars($_SESSION['name'], ENT_QUOTES, 'UTF-8') : 'User';

require_once("include/conn.php");
$query = "SELECT * FROM quiz_topic";
$result = mysqli_query($conn,$query);

$query_resource = "SELECT * FROM resource";
$result_resource = mysqli_query($conn,$query_resource);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/water.css@2/out/water.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"/>
    <link rel="stylesheet" href="addresourcestyle.css">
      <title>Manage Resource</title>
    
</head>
<body>
    <main class="main">
    <nav class="navbar">
          <a href="lecturer_dashboard.php" class="logo">
            <button>Edusphere</button>
          </a>
            <ul class="menu-bar">
                <li class="dropdown">
                  <a class="dropdown-text" href="lecturer_dashboard.php">Home</a>
                </li>
                <li class="dropdown">
                  <a class="dropdown-text" href="#">Resources</a>
        
                  <ul class="menu resources">
                    <li>
                      <a href="manage_quiz.php">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Manage Quiz
                      </a>
                    </li>
                    <li>
                        <a href="manage_resource.php">
                            <i class="fa-solid fa-right-long menu-arrow"></i>
                            Manage Resource
                          </a>
                      </li>
                  </ul>
                </li>
                <li class="dropdown">
                  <a class="dropdown-text" href="#">Contact</a>
        
                  <ul class="menu contact">
                    <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Head Quater
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Email Address
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Contact Number
                      </a>
                    </li>
                  </ul>
                </li>
        
                <li class="dropdown">
                  <a class="dropdown-text" href="lecturer_about_us.php">About</a>
                </li>
              </ul>

            <div class="profile-dropdown">
                <div onclick="toggle()" class="profile-dropdown-btn">
                  <div class="profile-img">
                    <i class="fa-solid fa-circle"></i>
                  </div>
        
                  <span
                    ><?php echo $name; ?>
                    <i class="fa-solid fa-angle-down"></i>
                  </span>
                </div>
        
                <ul class="profile-dropdown-list">
                  <li class="profile-dropdown-list-item">
                    <a href="view_lecturer_profile.php">
                      <i class="fa-regular fa-user"></i>
                      Edit Profile
                    </a>
                  </li>
        
                  <li class="profile-dropdown-list-item">
                    <a href="#">
                      <i class="fa-solid fa-sliders"></i>
                      Settings
                    </a>
                  </li>
        
                  <li class="profile-dropdown-list-item">
                    <a href="#">
                      <i class="fa-regular fa-circle-question"></i>
                      Help & Support
                    </a>
                  </li>
                  <hr />
        
                  <li class="profile-dropdown-list-item">
                    <a href="logout.php">
                      <i class="fa-solid fa-arrow-right-from-bracket"></i>
                      Log out
                    </a>
                  </li>
                </ul>
              </div>
            </nav>
        
          <h1>Resource Manager</h1>
          <div class="overlay" id="overlay"></div>

          <!--FORM FOR ADDING RESOURCE-->
          <form class="form" autocomplete="off" onsubmit="alert('form submitted!')" action="newResourceProcess.php" method="POST">

            <div class="bigtopic">
                <label id="topic" for="topic">Choose Topic:</label>
                <select name="topic" id="topic1">
                    <?php
                    //fetch and display
                        while($row = mysqli_fetch_assoc($result)) {
                            $id = $row['topic_id'];
                            $topic = $row['topic_name'];
                            echo "<option value='$id'>$topic</option>";
                        }
                    ?>
                </select>
            </div>

            <div id="quizbox">
                <div class="box1">
                    <div class="box2">
                        <label for="title"><b>Note title: </b></label>
                        <input required type="text" id="input" name="title" size="40">
                    </div>
                </div>

                <div class="box1">
                    <div class="box2">
                        <label for="answer1"><b>Note: </b></label>
                        <input required type="text" id="input" name="note" size="40">
                    </div>
                </div>

                <br><br>
                
            </div>
            <input type="submit" value="Finish!" id="submit" >
    </form>

    <div class="table-section">
            <table>
                <thead>
                    <tr>
                        <th>Topic</th>
                        <th>Resource_ID</th>
                        <th>Note</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        $count = 1;
                        while($row = mysqli_fetch_assoc($result_resource)) {
                            echo "<tr data-id='" . $row['topic_id'] . "'>";
                            echo "<td>" . $row['topic_id'] . "</td>";
                            echo "<td>" . $row['resource_id'] . "</td>";
                            echo "<td>" . $row['note'] . "</td>";

                            $count++;
                        }
                    } else {
                        echo "<tr><td colspan='7'>No records found</td></tr>";
                    }
                    $conn->close();
                    ?>
                </tbody>
            </table>
      </div>
      
    <form class="bigtopic" action="deleteResourceProcess.php" method="POST">
      <div id="topic">
        <label class="label" for="resource_id"> Resource_ID</label>
        <input id="input" type="text" name="resourcedeleteid" placeholder="Enter resource ID"><br>
        <input id="delete-btn" type="submit" value="Delete">
            </div>
      </form>
    </div>
    </main>

</body>
</html>

