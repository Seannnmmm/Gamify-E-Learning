<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="logo.jpeg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
    />
    <title>Edusphere-Result</title>
    <link rel="stylesheet" href="resultstyle4.css">
</head>

<body>
    <div class="result-box">
        <h2>Quiz Result!</h2>
        <div class="percentage-container">
            <div class="circular-progress">
                <span class="progress-value">60%</span>
            </div>

            <span class="score-text">Your Score 6 out of 10</span>
        </div>

        <div class="buttons">
            <a href="quizrecord.php">
                <button class="goHome-btn">Go back</button>
            </a>
        </div>
    </div>
    
</body>
</html>