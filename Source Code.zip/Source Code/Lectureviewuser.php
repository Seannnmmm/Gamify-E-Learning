<?php
$servername = "localhost";
$username = "root";  // your phpMyAdmin username
$password = "";      // your phpMyAdmin password
$lecturer_dbname = "lecturer_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $lecturer_dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch lecturer data
$sql = "SELECT * FROM users";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="logo.jpeg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"/>
    <title>Lecture View User</title>
    <link rel="stylesheet" href="Viewuser1.css">
</head>

<body>
    <div class="table">
        <div class="table-header">
            <a href="admin_dashboard.php">
            <p>View User</p>
            <div style="text-align:center;">
                <a href="Viewuser.php">
                    <button class="button">ADMIN</button>
                </a>
                <a href="LectureViewUser.php">
                    <button class="button">LECTURE</button>
                </a>
                <a href="Studentviewuser.php">
                    <button class="button">STUDENT</button>
                </a>
            </div>
            <div>
                <input placeholder="Search....."/>
            </div>
        </div>
        <div class="table-section">
            <table>
                <thead>
                    <tr>
                        <th>No. <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Username <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Lecturer ID <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Email Address <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Birthday <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Password <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        $count = 1;
                        while($row = $result->fetch_assoc()) {
                            echo "<tr data-id='" . $row['id'] . "'>";
                            echo "<td>" . $count . "</td>";
                            echo "<td class='username'>" . $row['username'] . "</td>";
                            echo "<td>" . $row['role_id'] . "</td>";
                            echo "<td class='email'>" . $row['email'] . "</td>";
                            echo "<td class='birthday'>" . $row['date_of_birth'] . "</td>";
                            echo "<td class='password'>********</td>";
                            echo "<td>
                                    <button class='edit-button'>Edit</button>
                                    <button class='delete-button'>Delete</button>
                                    <button class='save-button' style='display:none;'>Save</button>
                                    <button class='cancel-button' style='display:none;'>Cancel</button>
                                  </td>";
                            echo "</tr>";
                            $count++;
                        }
                    } else {
                        echo "<tr><td colspan='7'>No records found</td></tr>";
                    }
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="Viewuser2.js">
        
    </script>
</body>
</html>
