<?php

session_start();
include "include/conn.php";

$question_text = $_POST["question"];
$selected = $_POST["questionselection"];
$choice1 = $_POST["choice1"];
$choice2 = $_POST["choice2"];
$choice3 = $_POST["choice3"];
$choice4 = $_POST["choice4"];
$answer = $_POST["answer"];

$sql_question = "UPDATE quiz_question SET question_text = '$question_text' WHERE question_id = '$selected'";

$sql_choice = "UPDATE quiz_choice SET choice1 = '$choice1', choice2 = '$choice2', choice3 = '$choice3', choice4 = '$choice4', answer= '$answer' WHERE question_id = '$selected'";

// echo $sql;
$result = mysqli_query($conn, $sql_question);

$result2 = mysqli_query($conn,$sql_choice);

echo "Edit successful!"
?>


