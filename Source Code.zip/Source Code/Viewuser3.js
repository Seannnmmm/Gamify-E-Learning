const search = document.querySelector('input'),
    table_rows = document.querySelectorAll('tbody tr'),
    table_headings = document.querySelectorAll('thead th');

search.addEventListener('input', searchTable);

function searchTable() {
    table_rows.forEach((row, i)=> {
        console.log(row.textContent);
        let table_data = row.textContent, 
            search_data = search.value;

            row.classList.toggle('hide', table_data.indexOf(search_data) < 0);
            row.style.setProperty('--delay', i / 25 + 's');
    })

    document.querySelectorAll('tbody tr:not(.hide)').forEach((visible_row, i) => {
        visible_row.style.backgroundColor = (i % 2 == 0) ? 'transparent' : '#0000000b'

    });
}

table_headings.forEach((head, i) => {
    let sort_asc = true;
    head.onclick = () => {
        table_headings.forEach(head => head.classList.remove('active'));
        head.classList.add('active');

        document.querySelectorAll('td').forEach(td => td.classList.remove('active'))
        table_rows.forEach(row => {
            row.querySelectorAll('td')[i].classList.add('active')
        })

        head.classList.toggle('asc', sort_asc);
        sort_asc = head.classList.contains('asc') ? false : true;

        sortTable(i, sort_asc);
    }
})

function sortTable(column, sort_asc) {
    [...table_rows].sort((a, b) => {
        let first_row = a.querySelectorAll('td')[column].textContent.toLowerCase(),
            second_row = b.querySelectorAll('td')[column].textContent.toLowerCase();

        return sort_asc ? (first_row < second_row ? 1 : -1) : (first_row < second_row ? -1 : 1);
    })
        .map(sorted_row => document.querySelector('tbody').appendChild(sorted_row))
}

document.querySelectorAll('.edit-button').forEach(button => {
    button.addEventListener('click', function() {
        const row = this.closest('tr');
        row.querySelectorAll('td.username, td.email, td.birthday, td.password').forEach(td => {
            if (td.classList.contains('password')) {
                const input = document.createElement('input');
                input.type = 'password';
                input.placeholder = 'New Password';
                input.classList.add('editable');
                td.innerHTML = '';
                td.appendChild(input);
            } else {
                const input = document.createElement('input');
                input.value = td.innerText;
                input.classList.add('editable');
                td.innerHTML = '';
                td.appendChild(input);
            }
        });
        row.querySelector('.edit-button').style.display = 'none';
        row.querySelector('.save-button').style.display = 'inline-block';
        row.querySelector('.cancel-button').style.display = 'inline-block';
    });
});

document.querySelectorAll('.cancel-button').forEach(button => {
    button.addEventListener('click', function() {
        const row = this.closest('tr');
        row.querySelectorAll('td.username, td.email, td.birthday').forEach(td => {
            td.innerText = td.querySelector('input').value;
        });
        row.querySelector('.password').innerText = '********';
        row.querySelector('.edit-button').style.display = 'inline-block';
        row.querySelector('.save-button').style.display = 'none';
        row.querySelector('.cancel-button').style.display = 'none';
    });
});

document.querySelectorAll('.save-button').forEach(button => {
    button.addEventListener('click', function() {
        const row = this.closest('tr');
        const id = row.dataset.id;
        const username = row.querySelector('td.username input').value;
        const email = row.querySelector('td.email input').value;
        const birthday = row.querySelector('td.birthday input').value;
        const password = row.querySelector('td.password input').value;

        // AJAX request to save changes to the server
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'update_student.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                row.querySelector('td.username').innerText = username;
                row.querySelector('td.email').innerText = email;
                row.querySelector('td.birthday').innerText = birthday;
                row.querySelector('.password').innerText = '********';
                row.querySelector('.edit-button').style.display = 'inline-block';
                row.querySelector('.save-button').style.display = 'none';
                row.querySelector('.cancel-button').style.display = 'none';
            }
        };
        xhr.send('id=' + id + '&username=' + username + '&email=' + email + '&birthday=' + birthday + '&password=' + password + '&action=update');
    });
});

document.querySelectorAll('.delete-button').forEach(button => {
    button.addEventListener('click', function() {
        const row = this.closest('tr');
        const id = row.dataset.id;

        // AJAX request to delete the user from the server
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'update_student.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                if (xhr.responseText.trim() === 'User deleted successfully') {
                    row.remove();
                } else {
                    alert('Failed to delete user.');
                }
            }
        };
        xhr.send('id=' + id + '&action=delete');
    });
});

