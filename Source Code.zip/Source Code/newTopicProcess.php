<?php

require_once("include/conn.php");

$topic = $_POST['topic'];

$sql = "INSERT INTO quiz_topic (topic_name)
        VALUES(?)"; //placeholder to avoide sql injection

$stmt_topic = mysqli_stmt_init($conn);

if (! mysqli_stmt_prepare($stmt_topic,$sql)){
    die(mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt_topic,"s",
                        $topic);

mysqli_stmt_execute($stmt_topic);

echo "Record Saved.";