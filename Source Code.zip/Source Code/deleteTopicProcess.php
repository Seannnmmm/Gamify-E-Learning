<?php

require_once("include/conn.php");

$id = $_POST["topicdeleteid"];


$query = "DELETE FROM quiz_topic WHERE topic_id = $id";


if (mysqli_query($conn, $query)) {
    echo "Topic with ID $id has been deleted successfully.";
} else {
    echo "Error deleting topic: " . mysqli_error($conn);
}

?>