<?php
// register.php
$servername = "localhost";
$username = "root";  // your phpMyAdmin username
$password = "";      // your phpMyAdmin password
$admin_dbname = "admin_db";
$lecturer_dbname = "lecturer_db";

// Create connections
$admin_conn = new mysqli($servername, $username, $password, $admin_dbname);
$lecturer_conn = new mysqli($servername, $username, $password, $lecturer_dbname);

// Check connections
if ($admin_conn->connect_error) {
    die("Connection failed: " . $admin_conn->connect_error);
}
if ($lecturer_conn->connect_error) {
    die("Connection failed: " . $lecturer_conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name']; 
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_POST['email'];
    $date_of_birth = $_POST['date_of_birth'];
    $role = $_POST['role'];

    $conn = ($role == 'admin') ? $admin_conn : $lecturer_conn;

    // Generate a unique role_id based on the role
    $sql = "SELECT MAX(role_id) AS max_id FROM users WHERE role='$role'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $role_id = ($row['max_id'] !== null ? $row['max_id'] : 0) + 1;

    $sql = "INSERT INTO users (name, username, password, email, date_of_birth, role, role_id) VALUES ('$name', '$username', '$password', '$email', '$date_of_birth', '$role', '$role_id')";

    if ($conn->query($sql) === TRUE) {
        echo "Registration successful. <a href='admin_dashboard.php'>OK</a>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
