<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="logo.jpeg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
    />
    <title>Edusphere-Word Scramble</title>
    <link rel="stylesheet" href="scramblestyle.css">
</head>

  <body>

    <div class="container">

        <h2>Word Scramble Game</h2>
        <center><div class="startArea" onclick="start()"><button class="startBtn">Start the Game</button></div></center>

        <div class="content">
            <p class="word"></p>
            <div class="details">
                <p class="hint">Hint: <span></span></p>
                <p class="time">Time Left: <span><b>30</b>s</span></p>
            </div>
            <input type="text" spellcheck="false" placeholder="Enter a valid word">
            <div class="buttons">
                <button class="refresh-word">Refresh Word</button>
                <button class="check-word">Check Word</button>
            </div>
            <div class="score-area"><span>Score: </span><span class="score">0</span></div>
        </div>
    </div>

    
  <!-- The Modal -->
  <div id="myModal" class="modal">
    <!-- Modal content -->
    <div class="modal-content">
      <span class="close">&times;</span>
      <p id="modalText"></p>
    </div></div>

    <script src="scramblewordlist.js" defer></script>
    <script src="scramblescript.js" defer></script>
  </body>
</html>