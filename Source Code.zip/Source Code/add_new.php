<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View By</title>
    <link rel="stylesheet" href="css/add_new.css">
</head>

<body>
<a href="lecturer_dashboard.php">
  <div class="table-header">
      <p>New</p>
  </div>
</a>  
    
    <div class="title"><b>ADD NEW TOPIC/QUIZ</b></div>

    
    <div class="wrapper">

        <a href="new_topic.php">
            <div class="box1">
                <div>
                    <img id="plus" src="Image/Plus_Sign-removebg-preview.png" alt="">
                    <b class="b2">NEW TOPIC</b>
                </div>
            </div>
        </a>
            
        <div class="vl"></div>
        
        <a href="new_quiz.php">
            <div class="box2">
                <div>
                    <img id="plus" src="Image/Plus_Sign-removebg-preview.png" alt="">
                    <b class="b2">NEW QUIZ</b>
                </div>
            </div>
        </a>
    </div>
    
    <a href="manage_quiz.php">
        <input id="back-btn" type="button" value="Back to Manage Quiz" class="back">
    </a>

</body>
</html>