<!DOCTYPE php>
<php lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="logo.jpeg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
    />
    <title>Edusphere-Quiz Record(Extra Exercise)</title>
    <link rel="stylesheet" href="extrastyle.css">
</head>

<body>
    <div class="table">
        <a href="student_dashboard.php">
        <div class="table-header">
            <p>Quiz Record</p>
            </a>
            <div>
                <input placeholder="Search....."/>
            </div>
        </div>
        <div class="table-section">
            <table>
                <thead>
                    <tr>
                        <th>No. <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Name <span class="icon-arrow">&UpArrow;</span></th>
                        <th>TP Number <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Class <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Date <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Quiz <span class="icon-arrow">&UpArrow;</span></th>
                        <th>Result</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Mia</td>
                        <td>TP070738</td>
                        <td>Class C</td>
                        <td>04/04/2024</td>
                        <td>Quiz 2</td>
                        <td>
                        <a href="result11.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Elizabeth</td>
                        <td>TP070981</td>
                        <td>Class B</td>
                        <td>01/04/2024</td>
                        <td>Quiz 2</td>
                        <td>
                        <a href="result12.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Jassie</td>
                        <td>TP070888</td>
                        <td>Class A</td>
                        <td>21/03/2024</td>
                        <td>Quiz 1</td>
                        <td>
                        <a href="result13.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>Grace</td>
                        <td>TP060791</td>
                        <td>Class D</td>
                        <td>08/05/2024</td>
                        <td>Quiz 3</td>
                        <td>
                        <a href="result14.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>Kingston</td>
                        <td>TP060354</td>
                        <td>Class D</td>
                        <td>12/06/2024</td>
                        <td>Quiz 3</td>
                        <td>
                        <a href="result15.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>Lenny</td>
                        <td>TP070313</td>
                        <td>Class A</td>
                        <td>15/04/2024</td>
                        <td>Quiz 1</td>
                        <td>
                        <a href="result16.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td>Eugene</td>
                        <td>TP070455</td>
                        <td>Class C</td>
                        <td>09/05/2024</td>
                        <td>Quiz 2</td>
                        <td>
                        <a href="result17.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>8</td>
                        <td>Sheree</td>
                        <td>TP070523</td>
                        <td>Class B</td>
                        <td>23/05/2024</td>
                        <td>Quiz 1</td>
                        <td>
                        <a href="result18.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>9</td>
                        <td>Addy</td>
                        <td>TP060588</td>
                        <td>Class D</td>
                        <td>11/06/2024</td>
                        <td>Quiz 3</td>
                        <td>
                        <a href="result19.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>10</td>
                        <td>Kelly</td>
                        <td>TP070982</td>
                        <td>Class A</td>
                        <td>08/01/2024</td>
                        <td>Quiz 2</td>
                        <td>
                        <a href="result20.php">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <!-- <tr>
                        <td>11</td>
                        <td>Jamie</td>
                        <td>TP060321</td>
                        <td>Class B</td>
                        <td>18/03/2024</td>
                        <td>Quiz 3</td>
                        <td>
                        <a href="Result/">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>12</td>
                        <td>Ella</td>
                        <td>TP070024</td>
                        <td>Class D</td>
                        <td>15/03/2024</td>
                        <td>Quiz 1</td>
                        <td>
                        <a href="Result/">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>13</td>
                        <td>Joey</td>
                        <td>TP060258</td>
                        <td>Class A</td>
                        <td>05/01/2024</td>
                        <td>Quiz 1</td>
                        <td>
                        <a href="Result/">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>14</td>
                        <td>Vin</td>
                        <td>TP070584</td>
                        <td>Class C</td>
                        <td>02/06/2024</td>
                        <td>Quiz 2</td>
                        <td>
                        <a href="Result/">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr>
                    <tr>
                        <td>15</td>
                        <td>Naomi</td>
                        <td>TP060478</td>
                        <td>Class B</td>
                        <td>28/04/2024</td>
                        <td>Quiz 3</td>
                        <td>
                        <a href="Result/">
                            <button><i class="fa-solid fa-folder"></i></button>
                        </a>
                        </td>
                    </tr> -->
                </tbody>
            </table>
        </div>
    </div>

    <script src="extrascript.js"></script>
</body>

</html>