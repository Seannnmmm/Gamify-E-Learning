<?php
// logout.php
session_start();
session_destroy();
header("Location: homepage.html");  // Redirect to a common login page or you can create a landing page that links to both login forms
?>
