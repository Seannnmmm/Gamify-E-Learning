<?php
// dashboard.php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Ensure that the session contains the name of the user
$name = isset($_SESSION['name']) ? htmlspecialchars($_SESSION['name'], ENT_QUOTES, 'UTF-8') : 'User';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="logo.jpeg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"/>
    <title>Edusphere</title>
    <link rel="stylesheet" href="style2.css">
</head>

<body>
    <main class="main">
         <nav class="navbar">
          <a href="lecturer_dashboard.php" class="logo">
            <button>Edusphere</button>
          </a>
            <ul class="menu-bar">
                <li class="dropdown">
                  <a class="dropdown-text" href="lecturer_dashboard.php">Home</a>
                </li>
                <li class="dropdown">
                  <a class="dropdown-text" href="#">Resources</a>
        
                  <ul class="menu resources">
                    <li>
                      <a href="manage_quiz.php">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Manage Quiz
                      </a>
                    </li>
                    <li>
                        <a href="manage_resource.php">
                            <i class="fa-solid fa-right-long menu-arrow"></i>
                            Manage Resource
                          </a>
                      </li>
                  </ul>
                </li>
                <li class="dropdown">
                  <a class="dropdown-text" href="#">Contact</a>
        
                  <ul class="menu contact">
                    <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Head Quater
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Email Address
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Contact Number
                      </a>
                    </li>
                  </ul>
                </li>
        
                <li class="dropdown">
                  <a class="dropdown-text" href="lecturer_about_us.php">About</a>
                </li>
              </ul>

            <div class="profile-dropdown">
                <div onclick="toggle()" class="profile-dropdown-btn">
                  <div class="profile-img">
                    <i class="fa-solid fa-circle"></i>
                  </div>
        
                  <span
                    ><?php echo $name; ?>
                    <i class="fa-solid fa-angle-down"></i>
                  </span>
                </div>
        
                <ul class="profile-dropdown-list">
                  <li class="profile-dropdown-list-item">
                    <a href="view_lecturer_profile.php">
                      <i class="fa-regular fa-user"></i>
                      Edit Profile
                    </a>
                  </li>
        
                  <li class="profile-dropdown-list-item">
                    <a href="#">
                      <i class="fa-solid fa-sliders"></i>
                      Settings
                    </a>
                  </li>
        
                  <li class="profile-dropdown-list-item">
                    <a href="#">
                      <i class="fa-regular fa-circle-question"></i>
                      Help & Support
                    </a>
                  </li>
                  <hr />
        
                  <li class="profile-dropdown-list-item">
                    <a href="logout.php">
                      <i class="fa-solid fa-arrow-right-from-bracket"></i>
                      Log out
                    </a>
                  </li>
                </ul>
              </div>
            </nav>

            <section class="home">
                <div class="home-content">
                    <h1>Welcome to Edusphere!</h1>
                </div>
            </section>

    </main>

    <script src="script2.js"></script>
</body>

</html>