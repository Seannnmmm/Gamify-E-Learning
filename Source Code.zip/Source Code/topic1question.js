let questions = [
    {
        numb: 1,
        question: "What is a network?",
        answer: "A. A network consists of two or more separate devices linked together such that they can communicate.",
        options: [
            "A. A network consists of two or more separate devices linked together such that they can communicate.",
            "B. A network consists of only one devicethat they can communicate.",
            "C. A network consists of two or more separate devices are not linked together such that they can communicate.",
            "D. A network consists of two or more separate devices linked together but they cannot communicate."
        ]
    },
    {
        numb: 2,
        question: "What are NOT the types of networks?",
        answer: "C. WPN (Wide Private Network)",
        options: [
            "A. PAN (Personal Area Network)",
            "B. WPAN (Wireless Personal Area Network)",
            "C. WPN (Wide Private Network)",
            "D. WAN (Wide Area Netowrk)"

        ]
    },
    {
        numb: 3,
        question: "What is Network Cabling?",
        answer: "B. Network cables can connect two computers or computer systems directly.",
        options: [
            "A. Network cables cannot connect two computers or computer systems directly.",
            "B. Network cables can connect two computers or computer systems directly.",
            "C. Network cables can connect only one computer systems directly.",
            "D. Network cables can connect four computers or computer systems directly."
        ]
    },
    {
        numb: 4,
        question: "What are the types of network cables used in networking?",
        answer: "A. Wireless LANs",
        options: [
            "A. Wireless LANs",
            "B. Phone Cable",
            "C. Laptop Charger",
            "D. HDMI"
        ]
    },
    {
        numb: 5,
        question: "What is a 'subnet'?",
        answer: "A. A 'subnet' is a generic term for a section of an extensive network, usually separated by a bridge or a router.",
        options: [
            "A. A 'subnet' is a generic term for a section of an extensive network, usually separated by a bridge or a router.",
            "B. A 'subnet' is not a generic term for a section of an extensive network, usually separated by a bridge or a router.",
            "C. A 'subnet' is a generic term for a section of an exclusive network, usually separated by a bridge or a router.",
            "D. A 'subnet' is a generic term for a section of an extensive network, usually combined by a bridge or a router."
        ]
    },
    {
        numb: 6,
        question: "What is DNS?",
        answer: "D. The Domain Name System (DNS) is a central part of the internet, providing a way to match names to numbers.",
        options: [
            "A. The Domain Name System (DNS) is a neutral part of the internet, providing a way to match names to numbers.",
            "B. The Domain Name System (DNS) is a central part of the internet, doesn't need to match names to numbers.",
            "C. The Domain Name System (DNS) is a central part of the internet, providing a way to unmatched names to numbers.",
            "D. The Domain Name System (DNS) is a central part of the internet, providing a way to match names to numbers."
        ]
    },
    {
        numb: 7,
        question: "What is Network Topology?",
        answer: "C. Network topology is the physical or logical arrangement in which the devices or nodes of a network are interconnected over a communication medium.",
        options: [
            "A. Network topology is the physical or logical arrangement in which the devices or nodes of a network are connected over a communication medium.",
            "B. Network topology is the physical or logical management in which the devices or nodes of a network are interconnected over a communication medium.",
            "C. Network topology is the physical or logical arrangement in which the devices or nodes of a network are interconnected over a communication medium.",
            "D. Network topology is the physical or logical arrangement in which the devices or nodes of a network."
        ]
    },
    {
        numb: 8,
        question: "Which is the CORRECT types of network topologies?",
        answer: "A. Mesh",
        options: [
            "A. Mesh",
            "B. Bell",
            "C. Plant",
            "D. Tek"
        ]
    },
    {
        numb: 9,
        question: "What is a MAC address?",
        answer: "C. A MAC (Media Access Control) address is the unique 48-bit hardware address of a LAN card, usually stored in the ROM of the network adapter card.",
        options: [
            "A. A MAC (Media Access Control) address is the unique 64-bit hardware address of a LAN card, usually stored in the ROM of the network adapter card.",
            "B. A MAC (Media Access Control) address is the unique 48-bit hardware address of a LAN card, usually stored in the RAM of the network adapter card.",
            "C. A MAC (Media Access Control) address is the unique 48-bit hardware address of a LAN card, usually stored in the ROM of the network adapter card.",
            "D. A MAC (Media Access Control) address is the unique 48-bit hardware address of a WAN card, usually stored in the ROM of the network adapter card."
        ]
    },
    {
        numb: 10,
        question: "What is an IP address?",
        answer: "B. An Internet Protocol address (IP address) is a numerical unique address of a device in a network.",
        options: [
            "A. An Internet Procedure address (IP address) is a numerical unique address of a device in a network.",
            "B. An Internet Protocol address (IP address) is a numerical unique address of a device in a network.",
            "C. An Internet Protocol address (IP address) is a countable unique address of a device in a network.",
            "D. An Internet Protocol address (IP address) is not only a numerical unique address of a device in a network."
        ]
    },
];