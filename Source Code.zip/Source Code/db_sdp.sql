-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 17, 2024 at 04:10 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_sdp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_db`
--

CREATE TABLE `admin_db` (
  `admin_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `age` varchar(50) DEFAULT NULL,
  `onboard` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_db`
--

INSERT INTO `admin_db` (`admin_id`, `username`, `password`, `email`, `address`, `age`, `onboard`) VALUES
('', 'test', 'test123', 'test@mail.com', 'Bukit Jalil', '21', '2024-06-19');

-- --------------------------------------------------------

--
-- Table structure for table `history_quiz_record`
--

CREATE TABLE `history_quiz_record` (
  `record_id` varchar(50) NOT NULL,
  `quiz_title` varchar(50) NOT NULL,
  `quiz_questions` varchar(200) NOT NULL,
  `quiz_answer` varchar(200) NOT NULL,
  `date_answered` date NOT NULL,
  `student_answer` varchar(200) NOT NULL,
  `score` varchar(100) DEFAULT NULL,
  `student_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `history_quiz_record_db`
--

CREATE TABLE `history_quiz_record_db` (
  `record_id` varchar(50) NOT NULL,
  `quiz_title` varchar(50) NOT NULL,
  `quiz_questions` varchar(200) NOT NULL,
  `quiz_answer` varchar(200) NOT NULL,
  `date_answered` date NOT NULL,
  `student_answer` varchar(200) NOT NULL,
  `score` varchar(100) DEFAULT NULL,
  `student_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lecturer_db`
--

CREATE TABLE `lecturer_db` (
  `lecturer_id` varchar(50) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `age` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `student_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_choice`
--

CREATE TABLE `quiz_choice` (
  `choice_id` int(20) NOT NULL,
  `choice1` varchar(200) NOT NULL,
  `choice2` varchar(200) NOT NULL,
  `choice3` varchar(200) NOT NULL,
  `choice4` varchar(200) NOT NULL,
  `answer` varchar(200) NOT NULL,
  `question_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_choice`
--

INSERT INTO `quiz_choice` (`choice_id`, `choice1`, `choice2`, `choice3`, `choice4`, `answer`, `question_id`) VALUES
(1, 'A. A network consists of two or more separate devices linked together such that they can communicate.', 'B. A network consists of only one devicethat they can communicate.', 'C. A network consists of two or more separate devices are not linked together such that they can communicate.', 'D. A network consists of two or more separate devices linked together but they cannot communicate.', 'A. A network consists of two or more separate devices linked together such that they can communicate.', 1),
(2, 'A. PAN (Personal Area Network)', 'B. WPAN (Wireless Personal Area Network)', 'C. WPN (Wide Private Network)', 'D. WAN (Wide Area Netowrk)', 'C. WPN (Wide Private Network)', 2),
(3, 'A. Network cables cannot connect two computers or computer systems directly.', 'B. Network cables can connect two computers or computer systems directly.', 'C. Network cables can connect only one computer systems directly.', 'D. Network cables can connect four computers or computer systems directly.', 'B. Network cables can connect two computers or computer systems directly.', 3),
(4, 'A. Wireless LANs', 'B. Phone Cable', 'C. Laptop Charger', 'D. HDMI', 'A. Wireless LANs', 4),
(5, 'A. A \'subnet\' is a generic term for a section of an extensive network, usually separated by a bridge or a router.', 'B. A \'subnet\' is not a generic term for a section of an extensive network, usually separated by a bridge or a router.', 'C. A \'subnet\' is a generic term for a section of an exclusive network, usually separated by a bridge or a router.', 'D. A \'subnet\' is a generic term for a section of an extensive network, usually combined by a bridge or a router.', 'A. A \'subnet\' is a generic term for a section of an extensive network, usually separated by a bridge or a router.', 5),
(6, 'A. The Domain Name System (DNS) is a neutral part of the internet, providing a way to match names to numbers.', 'B. The Domain Name System (DNS) is a central part of the internet, doesn\'t need to match names to numbers.', 'C. The Domain Name System (DNS) is a central part of the internet, providing a way to unmatched names to numbers.', 'D. The Domain Name System (DNS) is a central part of the internet, providing a way to match names to numbers.', 'D. The Domain Name System (DNS) is a central part of the internet, providing a way to match names to numbers.', 6),
(7, 'A. Network topology is the physical or logical arrangement in which the devices or nodes of a network are connected over a communication medium.', 'B. Network topology is the physical or logical management in which the devices or nodes of a network are interconnected over a communication medium.', 'C. Network topology is the physical or logical arrangement in which the devices or nodes of a network are interconnected over a communication medium.', 'D. Network topology is the physical or logical arrangement in which the devices or nodes of a network.', 'C. Network topology is the physical or logical arrangement in which the devices or nodes of a network are interconnected over a communication medium.', 7),
(8, 'A. Mesh', 'B. Bell', 'C. Plant', 'D. Tek', 'A. Mesh', 8),
(9, 'A. A MAC (Media Access Control) address is the unique 64-bit hardware address of a LAN card, usually stored in the ROM of the network adapter card.', 'B. A MAC (Media Access Control) address is the unique 48-bit hardware address of a LAN card, usually stored in the RAM of the network adapter card.', 'C. A MAC (Media Access Control) address is the unique 48-bit hardware address of a LAN card, usually stored in the ROM of the network adapter card.', 'D. A MAC (Media Access Control) address is the unique 48-bit hardware address of a WAN card, usually stored in the ROM of the network adapter card.', 'C. A MAC (Media Access Control) address is the unique 48-bit hardware address of a LAN card, usually stored in the ROM of the network adapter card.', 9),
(10, 'A. An Internet Procedure address (IP address) is a numerical unique address of a device in a network.', 'B. An Internet Protocol address (IP address) is a numerical unique address of a device in a network.', 'C. An Internet Protocol address (IP address) is a countable unique address of a device in a network.', 'D. An Internet Protocol address (IP address) is not only a numerical unique address of a device in a network.', 'B. An Internet Protocol address (IP address) is a numerical unique address of a device in a network.', 10),
(11, 'A. A firewall is a protocol security system responsible for managing network traffic.', 'B. It uses a set of security rules to give remote access and content filtering.', 'C. A firewall is a network security system responsible for managing network traffic.', 'D. It is not uses a set of security rules to prevent remote access and content filtering.', 'C. A firewall is a network security system responsible for managing network traffic.', 11),
(12, 'A. The firewall accept for what information packets are trying to leave or enter the computer system.', 'B. The firewall ‘listens’ for what information packets are trying to leave or enter the computer system.', 'C. The firewall without follow for what information packets are trying to leave or enter the computer system.', 'D. The firewall uses what information packets are trying to leave or enter the computer system.', 'B. The firewall ‘listens’ for what information packets are trying to leave or enter the computer system.', 12),
(13, 'A. Simplex', 'B. Half-duplex', 'C. Full-duplex', 'D. Extra Full-duplex', 'D. Extra Full-duplex', 13),
(14, 'A. A router is a computer and networking device that forwards data packets between computer networks, including internetworks such as the global Internet.', 'B. A router[a] is a computer and networking device that recieve data packets between computer networks, including internetworks such as the global Internet.', 'C. A router[a] is a computer and networking device that forwards data packets between computer networks, excluding internetworks such as the global Internet.', 'D. A router[a] is a computer and networking device that forwards data packets between router, including internetworks such as the global Internet.', 'A. A router is a computer and networking device that forwards data packets between computer networks, including internetworks such as the global Internet.', 14),
(15, 'A. Longest prefix match', 'B. Minimum AD (administrative distance)', 'C. Maximum AD (administrative distance)', 'D. Lowest metric value', 'C. Maximum AD (administrative distance)', 15),
(16, 'A. Update password once', 'B. Ensure firewalls are set and configured properly', 'C. Install a unreliable antivirus program', 'D. Not update firewall regularly', 'B. Ensure firewalls are set and configured properly', 16),
(17, 'A. TELNET is a client-service procedure on the internet or local area network, allowing a user to log on to a remote device and have access to it.', 'B. TELNET is a client-service protocol on the internet or foreign area network, allowing a user to log on to a remote device and have access to it.', 'C. TELNET is a client-service protocol on the internet or local area network, not allowing a user to log on to a remote device and have access to it.', 'D. TELNET is a client-service protocol on the internet or local area network, allowing a user to log on to a remote device and have access to it.', 'D. TELNET is a client-service protocol on the internet or local area network, allowing a user to log on to a remote device and have access to it.', 17),
(18, 'A. Modems', 'B. Satellites', 'C. Computer Memory', 'D. Router', 'D. Router', 18),
(19, 'A. Proxy servers prevent internal users from identifying the IP addresses of an external network.', 'B. Proxy servers prevent external users from identifying the IP addresses of an internal network.', 'C. Proxy servers access external users from identifying the IP addresses of an internal network.', 'D. Proxy servers prevent external users from confirming the IP addresses of an internal network.', 'B. Proxy servers prevent external users from identifying the IP addresses of an internal network.', 19),
(20, 'A. They make a network virtually invisible to external users, who cannot identify the physical location of a network.', 'B. They make a network virtually invisible to internal users, who cannot identify the physical location of a network.', 'C. They make a network virtually invisible to external users, who can identify the physical location of a network.', 'D. They make a network virtually invisible to internal users, who can identify the physical location of a network.', 'A. They make a network virtually invisible to external users, who cannot identify the physical location of a network.', 20),
(21, 'A. Only devices points on a more extensive network are known as nodes.', 'B. Only data points on a more extensive network are known as nodes.', 'C. Devices or data points on a more exclusive network are known as nodes.', 'D. Devices or data points on a more extensive network are known as nodes.', 'D. Devices or data points on a more extensive network are known as nodes.', 21),
(22, 'A. A link is the physical and logical network component for interconnecting hosts or nodes in a network.', 'B. A link is just a physical network component for interconnecting hosts or nodes in a network.', 'C. A link is just a logical network component for interconnecting hosts or nodes in a network.', 'D. A link is the physical and logical network component for connecting hosts in a network.', 'A. A link is the physical and logical network component for interconnecting hosts or nodes in a network.', 22),
(23, 'A. SLIP, or Serial Line Interface Procedure, was developed during the early UNIX days and is used for remote access.', 'B. SLIP, or Serial Line Internal Protocol, was developed during the early UNIX days and is used for remote access.', 'C. SLIP, or Serial Line Interface Protocol, was developed during the early UNIX days and is used for remote access.', 'D. SLIP, or Serial Line Interface Protocol, was developed during the late UNIX days and is used for remote access.', 'C. SLIP, or Serial Line Interface Protocol, was developed during the early UNIX days and is used for remote access.', 23),
(24, 'A. It is a set of protocol layers designed to facilitate data interchange on homogeneous networks.', 'B. It is a set of protocol layers designed to facilitate data exchange on homogeneous networks.', 'C. It is a set of protocol layers designed to facilitate data exchange on heterogeneous networks.', 'D. It is a set of procedure layers designed to facilitate data exchange on heterogeneous networks.', 'C. It is a set of protocol layers designed to facilitate data exchange on heterogeneous networks.', 24),
(25, 'A. Application conflicts', 'B. Procedure mismatch', 'C. Client-server problems', 'D. Configuration error', 'B. Procedure mismatch', 25),
(26, 'A. Encryption changes data from its original readable to unreadable format, thus ensuring network security.', 'B. Encryption changes data from its original unreadable to readable format, thus ensuring network security.', 'C. Encryption changes data from its original readable format, thus ensuring network security.', 'D. Encryption changes data from its original unreadable format, thus ensuring network security.', 'A. Encryption changes data from its original readable to unreadable format, thus ensuring network security.', 26),
(27, 'A. It is a complex protocol that exchanges information between the routers.', 'B. It is a simple protocol that exchanges information between the modems.', 'C. It is a simple protocol that exchanges information between the routers.', 'D. It is a simple protocol that keeps information between the routers.', 'C. It is a simple protocol that exchanges information between the routers.', 27),
(28, 'A. The processes on each machine that communicate at a given layer are called the peer-peer process.', 'B. The processes on every machine that communicate at a given layer are called the peer-peer process.', 'C. The processes on each machine that communicate at a certain layer are called the peer-peer process.', 'D. The processes on each machine that interact at a given layer are called the peer-peer process.', 'A. The processes on each machine that communicate at a given layer are called the peer-peer process.', 28),
(29, 'A. Semantics', 'B. Syntax', 'C. Timing', 'D. Data', 'D. Data', 29),
(30, 'A. The maximum length of the Thinnet cable is 200 meters.', 'B. The maximum length of the Thinnet cable is 185 meters.', 'C. The maximum length of the Thinnet cable is 195 meters.', 'D. The maximum length of the Thinnet cable is 180 meters.', 'B. The maximum length of the Thinnet cable is 185 meters.', 30);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_db`
--

CREATE TABLE `quiz_db` (
  `quiz_id` varchar(50) NOT NULL,
  `quiz_title` varchar(50) NOT NULL,
  `quiz_questions` varchar(200) NOT NULL,
  `quiz_answer` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_question`
--

CREATE TABLE `quiz_question` (
  `question_id` int(20) NOT NULL,
  `question_text` varchar(200) NOT NULL,
  `topic_id` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_question`
--

INSERT INTO `quiz_question` (`question_id`, `question_text`, `topic_id`) VALUES
(1, 'What is a Network', 1),
(2, 'What are NOT the types of networks?', 1),
(3, 'What is Network Cabling?', 1),
(4, 'What are the types of network cables used in networking?', 1),
(5, 'What is a \'subnet\'?', 1),
(6, 'What is DNS?', 1),
(7, 'What is Network Topology?', 1),
(8, 'Which is the CORRECT types of network topologies?', 1),
(9, 'What is a MAC address?', 1),
(10, 'What is an IP address?', 1),
(11, 'What are ‘firewalls’?', 2),
(12, 'How does a firewall work?', 2),
(13, 'What are NOT the different ways to exchange data?', 2),
(14, 'What are routers?', 2),
(15, 'What are NOT the criteria for the best path selection of a router?', 2),
(16, 'How can you secure a computer network?', 2),
(17, 'What is TELNET?', 2),
(18, 'Which is NOT the uses of the Hamming code?', 2),
(19, 'What are proxy servers?', 2),
(20, 'How do they protect computer networks?', 2),
(21, 'What are Nodes?', 3),
(22, 'What are Links?', 3),
(23, 'What is SLIP?', 3),
(24, 'What is Transmission Control Protocol / Internet Protocol (TCP/IP)?', 3),
(25, 'What are NOT the common software problems lead to network defects?', 3),
(26, 'Why is encryption on a network necessary?', 3),
(27, 'What is Routing Information Protocol (RIP)?', 3),
(28, 'What is a peer-peer process?', 3),
(29, 'Which are NOT the main elements of a protocol?', 3),
(30, 'What is maximum length of the Thinnet Cable?', 3);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_result`
--

CREATE TABLE `quiz_result` (
  `result_id` int(20) NOT NULL,
  `score` int(30) DEFAULT NULL,
  `topic_id` int(20) DEFAULT NULL,
  `question_id` int(20) DEFAULT NULL,
  `choice_id` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_topic`
--

CREATE TABLE `quiz_topic` (
  `topic_id` int(20) NOT NULL,
  `topic_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_topic`
--

INSERT INTO `quiz_topic` (`topic_id`, `topic_name`) VALUES
(1, 'Topic 1 - Introduction to Networking'),
(2, 'Topic 2 - Basic Switch and End Device Configuration'),
(3, 'Topic 3 - Protocols and Models'),
(4, 'Topic 4 - DHCP');

-- --------------------------------------------------------

--
-- Table structure for table `resource`
--

CREATE TABLE `resource` (
  `resource_id` int(20) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `topic_id` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resource`
--

INSERT INTO `resource` (`resource_id`, `title`, `note`, `topic_id`) VALUES
(1, 'What is a Network?', 'Up to two or more connected computers which anables resource sharing', 1),
(2, 'Usage of Firewalls', 'Firewall provide protection by acting as a filter for your system from malicious or unnecessary traffic', 1),
(3, 'Usage of Switches', 'Switches can be used to Extend the Output of Connection via using LAN Cables', 2);

-- --------------------------------------------------------

--
-- Table structure for table `resource_db`
--

CREATE TABLE `resource_db` (
  `resource_id` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `link` varchar(250) NOT NULL,
  `image` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_db`
--

CREATE TABLE `student_db` (
  `student_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `birth_date` varchar(50) NOT NULL,
  `address` varchar(50) DEFAULT NULL,
  `age` int(2) DEFAULT NULL,
  `lecturer` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `User_Name` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`User_Name`, `Email`, `Phone`, `Password`) VALUES
('Sean', 'sean@mail.com', '012-3456789', 'sean123'),
('test', 'test@mail.com', '012-3456789', 'test123');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('admin') NOT NULL,
  `role_id` int(11) NOT NULL,
  `date_of_birth` date NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`, `role_id`, `date_of_birth`, `name`) VALUES
(6, 'aaron', '$2y$10$tGkqFS4H4TgbICO.hPZXze125W9kBNfPkQWbwafhKx3jcYCLF9YZS', 'aaron@gmail.com', 'admin', 1, '2024-06-28', 'aaron');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_db`
--
ALTER TABLE `admin_db`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `history_quiz_record`
--
ALTER TABLE `history_quiz_record`
  ADD PRIMARY KEY (`record_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `history_quiz_record_db`
--
ALTER TABLE `history_quiz_record_db`
  ADD PRIMARY KEY (`record_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `lecturer_db`
--
ALTER TABLE `lecturer_db`
  ADD PRIMARY KEY (`lecturer_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `quiz_choice`
--
ALTER TABLE `quiz_choice`
  ADD PRIMARY KEY (`choice_id`),
  ADD KEY `question_id` (`question_id`);

--
-- Indexes for table `quiz_db`
--
ALTER TABLE `quiz_db`
  ADD PRIMARY KEY (`quiz_id`);

--
-- Indexes for table `quiz_question`
--
ALTER TABLE `quiz_question`
  ADD PRIMARY KEY (`question_id`),
  ADD KEY `topic_id` (`topic_id`);

--
-- Indexes for table `quiz_result`
--
ALTER TABLE `quiz_result`
  ADD PRIMARY KEY (`result_id`);

--
-- Indexes for table `quiz_topic`
--
ALTER TABLE `quiz_topic`
  ADD PRIMARY KEY (`topic_id`);

--
-- Indexes for table `resource`
--
ALTER TABLE `resource`
  ADD PRIMARY KEY (`resource_id`),
  ADD KEY `topic_id` (`topic_id`);

--
-- Indexes for table `resource_db`
--
ALTER TABLE `resource_db`
  ADD PRIMARY KEY (`resource_id`);

--
-- Indexes for table `student_db`
--
ALTER TABLE `student_db`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `lecturer` (`lecturer`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`User_Name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `quiz_choice`
--
ALTER TABLE `quiz_choice`
  MODIFY `choice_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `quiz_question`
--
ALTER TABLE `quiz_question`
  MODIFY `question_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `quiz_topic`
--
ALTER TABLE `quiz_topic`
  MODIFY `topic_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `resource`
--
ALTER TABLE `resource`
  MODIFY `resource_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `history_quiz_record_db`
--
ALTER TABLE `history_quiz_record_db`
  ADD CONSTRAINT `history_quiz_record_db_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student_db` (`student_id`);

--
-- Constraints for table `lecturer_db`
--
ALTER TABLE `lecturer_db`
  ADD CONSTRAINT `lecturer_db_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student_db` (`student_id`);

--
-- Constraints for table `quiz_choice`
--
ALTER TABLE `quiz_choice`
  ADD CONSTRAINT `quiz_choice_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `quiz_question` (`question_id`);

--
-- Constraints for table `quiz_question`
--
ALTER TABLE `quiz_question`
  ADD CONSTRAINT `quiz_question_ibfk_1` FOREIGN KEY (`topic_id`) REFERENCES `quiz_topic` (`topic_id`);

--
-- Constraints for table `resource`
--
ALTER TABLE `resource`
  ADD CONSTRAINT `resource_ibfk_1` FOREIGN KEY (`topic_id`) REFERENCES `quiz_topic` (`topic_id`);

--
-- Constraints for table `student_db`
--
ALTER TABLE `student_db`
  ADD CONSTRAINT `student_db_ibfk_1` FOREIGN KEY (`lecturer`) REFERENCES `lecturer_db` (`lecturer_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
