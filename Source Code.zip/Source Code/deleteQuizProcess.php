<?php

require_once("include/conn.php");

$id = $_POST["deletequestion"];


$query_choice = "DELETE FROM quiz_choice WHERE question_id = $id";
$query = "DELETE FROM quiz_question WHERE question_id = $id";



if (mysqli_query($conn, $query_choice)) {
    echo "choice with ID $id has been deleted successfully.";
} else {
    echo "Error deleting choice: " . mysqli_error($conn);
}
if (mysqli_query($conn, $query)) {
    echo "question with ID $id has been deleted successfully.";
} else {
    echo "Error deleting question: " . mysqli_error($conn);
}

?>