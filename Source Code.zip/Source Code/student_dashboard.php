<?php
// dashboard.php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Ensure that the session contains the name of the user
$name = isset($_SESSION['name']) ? htmlspecialchars($_SESSION['name'], ENT_QUOTES, 'UTF-8') : 'User';

// Redirect based on role
if ($_SESSION['role'] == 'admin') {
    header("Location: admin_dashboard.php");
    exit();
} elseif ($_SESSION['role'] == 'lecturer') {
    header("Location: lecturer_dashboard.php");
    exit();
} elseif ($_SESSION['role'] != 'student') {
    echo "Access Denied";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="logo.jpeg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="    port" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"/>
    <title>Edusphere</title>
    <link rel="stylesheet" href="style2.css">
</head>

<body>
    <main class="main">
        <nav class="navbar">
            <a href="student_dashboard.php" class="logo">
                <button>Edusphere</button>
            </a>
            <ul class="menu-bar">
                <li class="dropdown">
                    <a class="dropdown-text" href="#">Home</a>
                </li>
                <li class="dropdown">
                    <a class="dropdown-text" href="#">Resources</a>
                    <ul class="menu resources">
                        <li>
                            <a href="#">
                                <i class="fa-solid fa-right-long menu-arrow"></i>
                                Quiz <i class="fa-solid fa-angle-right arrow-right"></i>
                            </a>
                            <ul class="sub-menu">
                                <li>
                                    <a target="_blank" href="topic1.php">
                                        <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                                        Topic 1
                                    </a>
                                </li>
                                <li>
                                <a target="_blank" href="topic2.php">
                                        <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                                        Topic 2
                                    </a>
                                </li>
                                <li>
                                <a target="_blank" href="topic3.php">
                                        <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                                        Topic 3
                                    </a>
                                </li>
                                
                            </ul>
                            
                        </li>
                        <li>
                      <a href="#">
                        <i class="fa-solid fa-right-long menu-arrow"></i>
                        Game Learning <i class="fa-solid fa-angle-right arrow-right"></i>
                      </a>
                        <ul class="sub-menu">
                          <li>
                            <a  target="_blank"  href="scramble.php
                            ">
                              <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                              Word Scramble</a
                            >
                          </li>
                          <li>
                            <a  target="_blank"  href="Hangman.php
                            ">
                              <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                              Hangman</a
                            >
                          </li>
                        </ul>
                    </li>
                        <li>
                            <a href="#">
                                <i class="fa-solid fa-right-long menu-arrow"></i>
                                Extra Exercise <i class="fa-solid fa-angle-right arrow-right"></i>
                            </a>
                            <ul class="sub-menu">
                                <li>
                                    <a target="_blank" href="extraexercise.php">
                                        <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                                        Quiz Record
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa-solid fa-right-long menu-arrow"></i>
                                Topic <i class="fa-solid fa-angle-right arrow-right"></i>
                            </a>
                            <ul class="sub-menu">
                                <li>
                                    <a target="_blank" href="quizrecord.php">
                                        <i class="fa-solid fa-right-long sub-menu-arrow"></i>
                                        Quiz Record
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="view_resource.php">
                                <i class="fa-solid fa-right-long menu-arrow"></i>
                                View Resource
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-text" href="#">Contact</a>
                    <ul class="menu contact">
                        <li>
                            <a href="#">
                                <i class="fa-solid fa-right-long menu-arrow"></i>
                                Head Quater
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa-solid fa-right-long menu-arrow"></i>
                                Email Address
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa-solid fa-right-long menu-arrow"></i>
                                Contact Number
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-text" href="student_about_us.php">About</a>
                </li>
            </ul>

            <div class="profile-dropdown">
                <div onclick="toggle()" class="profile-dropdown-btn">
                    <div class="profile-img">
                        <i class="fa-solid fa-circle"></i>
                    </div>

                    <span><?php echo $name; ?> 
                    <i class="fa-solid fa-angle-down"></i></span>
                </div>
                <ul class="profile-dropdown-list">
                    <li class="profile-dropdown-list-item">
                        <a href="view_profile.php">
                            <i class="fa-regular fa-user"></i>
                            Edit Profile
                        </a>
                    </li>
                    <li class="profile-dropdown-list-item">
                        <a href="#">
                            <i class="fa-solid fa-sliders"></i>
                            Settings
                        </a>
                    </li>
                    <li class="profile-dropdown-list-item">
                        <a href="#">
                            <i class="fa-regular fa-circle-question"></i>
                            Help & Support
                        </a>
                    </li>
                    <hr />
                    <li class="profile-dropdown-list-item">
                        <a href="logout.php">
                            <i class="fa-solid fa-arrow-right-from-bracket"></i>
                            Log out
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <section class="home">
                <div class="home-content">
                    <h1>Welcome to Edusphere!</h1>
                </div>
            </section>
    </main>
    <script src="script2.js"></script>
</body>
</html>
